package App;

/**
 * This class starts and stops the main update loop. The loop runs within its
 * own thread.
 * 
 * @version 1.0 May 2003
 * @author Tim Blackwell
 *  
 */
public class AnimatedLoop extends MainLoop {

    protected long time = System.currentTimeMillis();

    protected long interval = 20L;

    protected boolean pause = false;

    protected boolean fast = true;

    public AnimatedLoop(MSOApp m, int i, long ivl) {

        super(m, i);
        interval = ivl;
    }

    public void run() {

        super.run();
    }

    public void update() {

        if (!pause) {
            counter++;
            msoApp.update();
        }

        if (!fast) {
            try {
                time += interval;
                sleep(Math.max(0, time - System.currentTimeMillis()));

            } catch (InterruptedException e) {
            }
        }

        try {
            if (counter == maxIterations) {
                stopLoop();
            }

        } catch (Exception e) {
        }
    }

    public void stopLoop() {

        super.stopLoop();
    }

    public int getCounter() {
        return counter;
    }

    public void setInterval(long l) {
        interval = l;
    }

    public void setPause(boolean b) {
        pause = b;
    }

    public void setFast(boolean b) {
        fast = b;
    }

    public void setTime(long l) {
        time = l;
    }
}
