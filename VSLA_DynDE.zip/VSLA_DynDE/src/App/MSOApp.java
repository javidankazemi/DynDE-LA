package App;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import Functions.Cone;
import Functions.ObjectiveFunction;
import Functions.PeakFunction;
import Functions.Rastrigin;
import Functions.Rosenbrook;
import Functions.Sphere;
import Functions.MovingCone;
import MultiSwarm.MSO;
import Utilities.Application;
import Utilities.Data;

/*
 * Optimizes MPB function using multi-population differential evolution
 * with learning automata based function evaluation management (DynDE+LA).
 *
 * A seed fixes a pseudo random series of numbers that is used to set the spring
 * constants in the neutral individual update, position the Brownian individuals and
 * initialise all genomes in the search space both at the beginning and if
 * exclusion occurs.
 * 
 * The peak function has different instances, determined by another seed. Each
 * seeds determines the peak movements and changes.
 * 
 * Each experiment is defined on a specific function instance and lasts for a
 * certain number of function evaluations defined by the variable
 * changeFrequency.
 * 
 * The experiment is then repeated with a different function and algorithm
 * instances. The total number of experiments per run is set by the variable
 * numberOfFunctionInstances.
 * 
 * Different parameter settings for subsequent runs can be defined in the method
 * defineRunParameters(). The number of runs is determined by the variable
 * numberOfRuns.
 * 
 * 
 * For static environments, set changeFrequency to Integer.MAX_VALUE and
 * dynamicEnvironment to false. Then, number of iterations = number of evals /
 * total number of particles.
 *
 *
 * 
 * The number of charged particles means number of Brownian individuals
 *
 *  
 */

/*
 * HOW TO USE
 * 
 * Compile: javac -d classes MSOApp.java Run: java -cp classes MSOApp
 * 
 *
 * 
 * Exclusion cannot be turned off, but setting r_excl to 0.0 means that
 * exclusion will only apply to two coincident swarms (swarm attractors
 * coincide), a very unlikely possibility. Anti-convergence is turned off by
 * setting MSOApp.useAntiConvergence to false.
 *  
 */

/**
 * The basic DynDE was built upon the code of mQSO implemented by Tim Blackwell
 * 
 */
public class MSOApp extends Application {

    /*
     * Spatial parameters - dimensionality
     * 
     * Set to 5 for control experiment and MPB scenario 2
     */
    int numberOfDimensions = 5; // scenario 2

    /*
     * Spatial parameters - dynamic range Initial population configuration (x, v) is
     * random in [-D/2, D/2]**N where D is dynamic range and N is num of
     * dimensions
     */
    int dynamicRange = 100;

    /*
     * Function
     */
    ObjectiveFunction objectiveFunction;

    // This num is added to any function seed.
    // movpeaks.movrand and movpeaks.movnrand are initially
    // set at 1
    long functionSeed = 1135334590004L+150L;

    // Scenario 1: 5; Scenario 2: 10
    int numberOfAttractors = 10;

    // Scenario 1: 1.0; Scenario 2: 0.0 - 3.0
    double vlength = 1.0;

    // Scenario 1: 5000; Scenario 2: 1000-5000
    int changeFrequency = 5000;

    /*
     * Critrion for terminating by iterations - usually set this to
     * Integer.MAX_VALUE
     */
    int maxIterations = Integer.MAX_VALUE;

    /*
     * Experiment parameters
     * 
     * control experiment: numberOfFunctionInstances = 50 maxNumberOfEvals =
     * 500000
     */
    int numberOfFunctionInstances = 100;

    int currentInstance = 0;

    int maxNumberOfEvals = 500000;

    /*
     * Environment
     * 
     * Set dynamicEnvironment to false for static optimization When this is set
     * to true, test for change occurs at start of each population iteration
     */
    boolean dynamicEnvironment = true;

    final int PEAKS = 0;

    final int SPHERE = 1;

    final int ROSENBROOK = 2;

    final int RASTRIGIN = 3;

    final int CONE = 4;

    final int MOVINGCONE = 5;

    int currentFunction = PEAKS;

    /*
     * Algorithm parameters DynDE configuration
     * 
     * control: numberOfSwarms = 10; numberOfNeutralParticlesInSwarm = 5;
     * numberOfChargedParticlesInSwarm = 5; long msoSeed = 0; selfAdapt = false
     * 
     * REMEMBER TO USE JUST ONE SWARM IF SELFADAPT = TRUE
     * 
     */
    int numberOfSwarms = 1;

    int numberOfNeutralParticlesInSwarm = 4;

    int numberOfChargedParticlesInSwarm = 2;

    boolean selfAdapt = false;

    /*
     * Seed for RNG
     * 
     * msoSeed is added to mso.xSeed and mso.vSeed
     */
    long msoSeed = 1234567890123L;

    /*
     * Exclusion
     * 
     * Set exclusion to 0.0 to turn off Set exclusion to 31.5 for control
     * experiment
     */
    double exclusionRadius = 31.5;

    /*
     * Anti-convergence
     * 
     * Set convergenceRadius to 0.0 to turn off.
     */
    double convergenceRadius = 0.0;

    /*
     * DynDE parameters
     *
     */
    double F = 0.5; // 0.4
    boolean randomF;

    double CR = 0.5; // 0.6
    boolean randomCR;


    /*
     * Coulomb and quantum parameters
     * 
     * r_cloud is the same as perceptionLimit and is set to v_length for TEC
     * paper. Use 0.5 * v_length for the new uniform volume cloud distribution
     * MSO.getPointinHypersphere(double radius)
     */
    double particleCharge = 1.0;

    double perceptionLimit = 0.5 * vlength; // 0.5 * vlength
    
    double perceptionSigma = 0.2;

    /*
     * Run statistics
     * 
     * The arrays and ArrayList are initialised in setUpRun();
     */
    double[] results;

    double[] numIterations;

    double[] fevalsPerImprovement;

    ArrayList statisticsList;

    /*
     * These variables collect data for a single experiment
     */
    double averageChargedSwarmSize = 0.0;

    double averageSquareChargedSwarmSize = 0.0;

    double lastStatistic = Double.MAX_VALUE;

    int lastNumberOfEvals = 0;

    double instFevalsPerImprovement = 0.0;

    int numItems = 0;

    int tempMax = maxNumberOfEvals;

    /*
     * MSO and GUI objects
     */
    MSO mso;

    MSOAppGUI msoAppGUI;

    boolean showGUI = false;

    /*
     * Files and writers for output data
     */
    File infoFile;

    File file;

    PrintWriter infoOut;

    PrintWriter out;

    boolean printToFile = false;

    boolean printStatisticsEachIteration = false;

    boolean printContinuousStatistics = false;

    String outputDirectory = "Experiments";

    /*
     * MainLoop object, counter, start time
     */
    MainLoop mainLoop;

    int counter = 0;

    boolean waiting = true;

    long startTime = System.currentTimeMillis();

    /*
     * Display
     */
    boolean showAnimation = false;

    Display display;

    long interval = 20L;

    int xAxis = 0;

    int yAxis = 1;

    /*
     * Constructors
     */
    public MSOApp() {

        // Output files and writers
        if (printToFile) {
            setOutput();
        }

        if (showGUI)
            msoAppGUI = new MSOAppGUI(this);

        else
            waiting = false;

        setUpExperiment();
        init();

    }

    public MSOApp(int numSwarms, int numNeutral, int numCharged) {

        numberOfSwarms = numSwarms;
        numberOfNeutralParticlesInSwarm = numNeutral;
        numberOfChargedParticlesInSwarm = numCharged;

        // Output files and writers
        if (printToFile) {
            setOutput();
        }

        if (showGUI)
            msoAppGUI = new MSOAppGUI(this);

        else
            waiting = false;

        setUpExperiment();
        init();

    }

    public void setUpExperiment() {


         dynamicEnvironment = true;
         currentFunction = PEAKS;
         numberOfDimensions = 5; // Number of dimensions
                  
         numberOfSwarms = 10; // Number of populations 10
         vlength = 1.0; // Shift severity
         
         numberOfAttractors = 10; // Number of peaks
         numberOfNeutralParticlesInSwarm = 4; // Number DE individuals
         numberOfChargedParticlesInSwarm = 2; // Number of Brownian individuals
         selfAdapt = false;
         
         randomF = false; // Select F for each dimension of each individual from [0, 1]
         F = 0.5;
         
         randomCR = false; // Select CR for each individual from [0, 1]
         CR = 0.5;
         
         perceptionSigma = 0.2; // Standard deviation Sigma
         
         exclusionRadius = 31.5;
         //exclusionRadius = dynamicRange /(2.0*Math.pow(numberOfAttractors, ((double)1/(double)numberOfDimensions)));
         convergenceRadius = 0.0;
         int nChange = 100;
         changeFrequency = 5000;
         maxNumberOfEvals = 500000; //Termination condition
         
         
         numberOfFunctionInstances = 50; // Number of runs



        // Set up run details for all functions
        setUpRun();
    }

    /*
     * Initialise results arrays for a run of experiments. The number of
     * experiments in a run is determined by numberOfFunctionInstances.
     * 
     */
    public void setUpRun() {

        results = new double[numberOfFunctionInstances];
        numIterations = new double[numberOfFunctionInstances];
        fevalsPerImprovement = new double[numberOfFunctionInstances];
        statisticsList = new ArrayList();
    }

    /*
     * init() is called for each function instance i.e. for each experiment
     */
    public void init() {

        /*
         * Stop loop if not first run
         */
        if (mainLoop != null)
            mainLoop.stopLoop();

        /*
         * Instantiate new loop object for this run.
         * 
         * If not showing animation, set fast to true. Otherwise set to false
         * and can control speed of animation from GUI
         */
        mainLoop = new AnimatedLoop(this, maxIterations, interval);
        ((AnimatedLoop) mainLoop).setFast(!showAnimation);

        /*
         * Update GUI
         */
        if (showGUI)
            msoAppGUI.update();

        /*
         * Init the statistics variables for a single experiment
         */
        initExperimentStatistics();

        /*
         * Instantiate objective function
         */
        setUpFunction();

        /*
         * Instantiate MSO object
         */
        setUpMSO();

        // Finally need to re-set display and update GUI
        if (display != null) {

            display.setMSO(mso);
            display.setObjectiveFunction(objectiveFunction);
            display.repaint();
        }

        if (showGUI)
            msoAppGUI.update();

        while (waiting) {
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
            }
        }

        // Finished waiting - now run
        mainLoop.run();
    }

    public void start() {

        // Start main loop
        waiting = false;
    }

    private void initExperimentStatistics() {

        // initialise experiment statistics variables
        averageChargedSwarmSize = 0.0;
        averageSquareChargedSwarmSize = 0.0;
        lastNumberOfEvals = 0;
        lastStatistic = Double.MAX_VALUE;
        instFevalsPerImprovement = 0.0;
        numItems = 0;
        tempMax = maxNumberOfEvals;
    }

    public void setUpFunction() {

        // Objective Functions
        if (currentFunction == PEAKS) {

            objectiveFunction = new PeakFunction("Peak Function",
                    numberOfAttractors, numberOfDimensions, changeFrequency,
                    vlength, functionSeed, dynamicRange, maxNumberOfEvals, this);

        }

        if (currentFunction == SPHERE) {

            double[] sphereAttractor = new double[numberOfDimensions];
            double sphereHeight = 0.0;

            objectiveFunction = new Sphere("Sphere", sphereAttractor,
                    numberOfDimensions, changeFrequency, sphereHeight,
                    dynamicRange, maxNumberOfEvals, this);
        }

        if (currentFunction == ROSENBROOK) {

            double[] rosenbrookAttractor = new double[numberOfDimensions];
            double rosenbrookHeight = 0.0;

            objectiveFunction = new Rosenbrook("Rosenbrook",
                    rosenbrookAttractor, numberOfDimensions, changeFrequency,
                    rosenbrookHeight, dynamicRange, maxNumberOfEvals, this);
        }

        if (currentFunction == RASTRIGIN) {

            double[] rastriginAttractor = new double[numberOfDimensions];
            double rastriginHeight = 0.0;

            objectiveFunction = new Rastrigin("Rastrigin", rastriginAttractor,
                    numberOfDimensions, changeFrequency, rastriginHeight,
                    dynamicRange, maxNumberOfEvals, this);
        }

        if (currentFunction == CONE) {

            // Tan theta. Height of cone is radius * tan(theta)
            double tanTheta = 1.0;
            objectiveFunction = new Cone("Cone", numberOfDimensions,
                    functionSeed, dynamicRange, tanTheta, this);

        }

        if (currentFunction == MOVINGCONE) {

            // Tan theta. Height of cone is radius * tan(theta)
            double tanTheta = 1.0;

            // Amount to move cone
            vlength = 1.0;

            // Correlated (lambda = 1.0), uncorrelated (lambda = 0.0)
            double lambda = 0.0;

            // Assume one swarm. Set to change each iteration
            // NB there are 2N evals per itereatrion
            // where N is swarm size
            changeFrequency = 2 * (numberOfChargedParticlesInSwarm + numberOfNeutralParticlesInSwarm);

            // Make the function object
            objectiveFunction = new MovingCone("MovingCone",
                    numberOfDimensions, functionSeed, dynamicRange, tanTheta,
                    vlength, changeFrequency, lambda, this);

        }
    }

    public void setUpMSO() {

        // Number of particles in each swarm
        int numberOfParticlesInSwarm = numberOfNeutralParticlesInSwarm
                + numberOfChargedParticlesInSwarm;
        // MSO object
        mso = new MSO(numberOfSwarms, numberOfParticlesInSwarm,
                numberOfNeutralParticlesInSwarm,
                numberOfChargedParticlesInSwarm, particleCharge,
                numberOfDimensions, dynamicRange, msoSeed, selfAdapt,
                dynamicEnvironment);

        // Multiswarm parameters
        mso.setExclusionRadius(exclusionRadius);
        mso.setConvergenceRadius(convergenceRadius);

        // Set objective function
        mso.setObjectiveFunction(objectiveFunction);

        // PSO Parameters
        mso.setF(F);
        mso.setRandomF(randomF);
        mso.setCR(CR);
        mso.setRandomCR(randomCR);

        // CPSO Parameters
        mso.setPerceptionLimit(perceptionLimit);
        mso.setPerceptionSigma(perceptionSigma);
    }

    public void update() {

        counter = mainLoop.getCounter();

        if (showAnimation) {

            display.repaint();
        }

        mso.updateMultiSwarm();

        if (printStatisticsEachIteration) {
            printIterationStatistics();
            // printSwarmSize( 0 ); // size of swarm 0
        }
    }

    /*
     * This method is called by the function object at every evaluation. The
     * calling function passes value of any statistic, e.g. offline error
     * 
     */
    public void inform(int numberOfEvals, double statistic) {

        if (printContinuousStatistics) {

            // Decide when to store data
            // At regular intervals
            int evalInterval = maxNumberOfEvals / 100;
            if ((numberOfEvals == 1) || (numberOfEvals % evalInterval == 0)) {

                // for convergence plots
                Data data = new Data();
                data.addNumber(new Integer(numberOfEvals));
                data.addNumber(new Double(statistic));

                // for examination of num converged swarms
                // data.addNumber(new
                // Integer(mso.getNumberOfConvergedSwarms()));
                // data.addNumber(new Integer(mso.getNumberOfFreeSwarms()));

                statisticsList.add(data);
            }
        }

        if (statistic < lastStatistic) {

            double runningTotal = instFevalsPerImprovement * numItems;
            runningTotal += (numberOfEvals - lastNumberOfEvals);
            numItems++;
            instFevalsPerImprovement = runningTotal / numItems;

            // System.out.println("Relative improvement: " + (statistic -
            // lastStatistic) / lastStatistic);

            lastStatistic = statistic;
            lastNumberOfEvals = numberOfEvals;
            // System.out.println("Running Average:\t" +
            // instFevalsPerImprovement + "\n");

        }

        if (numberOfEvals % maxNumberOfEvals == 0 && numberOfEvals != 0) {
            // if (numberOfEvals % tempMax == 0 && numberOfEvals != 0) {

            // This experiment is over
            printExperimentStatistics();
            results[currentInstance] = statistic;
            fevalsPerImprovement[currentInstance] = instFevalsPerImprovement;
            numIterations[currentInstance] = mso.getNumberOfIterations();

            if (currentInstance == (numberOfFunctionInstances - 1)) {

                // The run is over.
                printParameters();
                printRunStatistics();

                close();

            } else {

                // The run is not over
                // Start new experiment with a new function instance
                currentInstance++;
                currentInstance %= numberOfFunctionInstances;

                // Start new experiment with same algorithm but with new
                // function instance.
                msoSeed++;
                functionSeed++;

                init();
            }
        }
    }

    public void close() {

        mainLoop.stopLoop();

        // printParameters();
        if (printContinuousStatistics) {

            int lastIntData = 0;
            double lastDoubleData = 0.0;
            int totalIntData = 0;
            int numIntData = 0;

            int intData = 0;
            double doubleData = 0.0;
            for (int i = 0; i < statisticsList.size(); i++) {

                Data data = (Data) statisticsList.get(i);
                Number[] numberArray = data.getData();
                for (int j = 0; j < numberArray.length; j++) {

                    if (numberArray[j] instanceof Integer) {
                        intData = ((Integer) numberArray[j]).intValue();
                        out.print(intData + "\t");

                    }

                    if (numberArray[j] instanceof Double) {
                        doubleData = ((Double) numberArray[j]).doubleValue();
                        out.print(doubleData + "\t");
                    }
                }
                out.print("\n");
            }
        }

        /*
         * Close file output
         */
        if (printToFile) {
            closeOutput();
        }

        /*
         * Dispose display and GUI
         */
        if (showAnimation) {
            display.dispose();
        }

        if (msoAppGUI != null) {
            msoAppGUI.dispose();
        }

        System.exit(0);
    }

    public double getCharge() {

        return particleCharge;
    }

    public void setCharges(double charge) {

        int numberOfParticlesInSwarm = numberOfNeutralParticlesInSwarm
                + numberOfChargedParticlesInSwarm;

        particleCharge = charge;
        mso.setParticleCharge(particleCharge);

        for (int n = 0; n < numberOfSwarms; n++) {

            for (int k = 0; k < numberOfParticlesInSwarm; k++) {
                int extra = 0;
                // Use this to add an extra charged particle
                // if ( n == 0 ) extra = 1;
                if (k < numberOfChargedParticlesInSwarm + extra) {

                    mso.setCharge(n, k, particleCharge);
                } else {

                    mso.setCharge(n, k, 0.0);
                }
            }
        }
    }

    private void printSwarmSize(int n) {

        double chargedSize = mso.swarmSize(n, particleCharge);
        averageChargedSwarmSize = (averageChargedSwarmSize * (counter - 1) + chargedSize)
                / counter;

        averageSquareChargedSwarmSize = (averageSquareChargedSwarmSize
                * (counter - 1) + chargedSize * chargedSize)
                / counter;
        double variance = (averageSquareChargedSwarmSize - averageChargedSwarmSize
                * averageChargedSwarmSize)
                / (counter - 1);
        double stdDev = Math.pow(variance, 0.5);
        System.out.println("Average for population " + n + " after " + counter
                + " iterations: " + averageChargedSwarmSize + "\t" + stdDev);
        // if ( counter == 10000 ) System.exit( 0 );

    }

    public void setAnimationSpeed(long l) {

        interval = l;
        if (showAnimation && (mainLoop instanceof AnimatedLoop)) {
            ((AnimatedLoop) mainLoop).setInterval(l);
        }
    }

    public void setPause(boolean b) {

        if (mainLoop instanceof AnimatedLoop) {
            ((AnimatedLoop) mainLoop).setPause(b);
        }
    }

    public void setMagnification(double d) {

        if (showAnimation) {
            display.setMagnification(d);
            display.repaint();
        }
    }

    public int getXAxis() {

        if (showAnimation)
            return display.getXAxis();
        else
            return xAxis;
    }

    public void setXAxis(int i) {

        if (showAnimation) {

            if (i >= 0 && i < numberOfDimensions) {

                xAxis = i;
                display.setXAxis(i);
            }
        }
    }

    public int getYAxis() {

        if (showAnimation)
            return display.getYAxis();
        else
            return yAxis;
    }

    public void setYAxis(int i) {

        if (showAnimation) {

            if (i >= 0 && i < numberOfDimensions) {

                yAxis = i;
                display.setYAxis(i);
            }
        }
    }

    public void setShowAnimation(boolean b) {

        if (showAnimation != b) {

            if (b) {

                showAnimation = true;
                if (mainLoop instanceof AnimatedLoop)
                    ((AnimatedLoop) mainLoop).setFast(false);
                setDisplay();
            }

            if (!b) {

                showAnimation = false;
                if (mainLoop instanceof AnimatedLoop)
                    ((AnimatedLoop) mainLoop).setFast(true);
                display.dispose();
            }
        }
    }

    public void setDisplay() {

        display = new Display(objectiveFunction, mso, xAxis, yAxis);
    }

    public void setOutput() {

        // Parameters to file
        infoFile = getNewInfoFile();
        infoOut = null;
        try {
            infoOut = new PrintWriter(new FileWriter(infoFile));
        } catch (IOException e) {
        }

        if (printContinuousStatistics) {

            // Run statistics to file
            out = null;
            file = null;
            try {
                file = getNewFile();
                out = new PrintWriter(new FileWriter(file));
            } catch (IOException e) {
            }
        }

    }

    public File getNewFile() {

        String nameStart = outputDirectory + File.separatorChar + "Experiment_";
        int i = 1;
        String fileName = nameStart + i;
        String fileType = ".txt";
        File f = new File(fileName + fileType);
        while (f.exists()) {
            i++;
            fileName = nameStart + i;
            f = new File(fileName + fileType);
        }
        return f;
    }

    public File getNewInfoFile() {

        String nameStart = outputDirectory + File.separatorChar + "Details_";
        int i = 1;
        String fileName = nameStart + i;
        String fileType = ".txt";
        File f = new File(fileName + fileType);
        while (f.exists()) {
            i++;
            fileName = nameStart + i;
            f = new File(fileName + fileType);
        }
        return f;
    }

    public void printFunction(int counter) {

        System.out.println("\nFunction at iteration: " + counter + "\n");
        objectiveFunction.print();
        System.out.println();
    }

    public void printIterationStatistics() {

        String message = "";
        message = "\nStatistics at iteration: " + mainLoop.getCounter() + "\n";
        message += "***************************\n\n";
        out(message);
        out(objectiveFunction.getStatistics());
        out("Best swarm: " + mso.getBestSwarm() + "\tbest value:\t"
                + mso.getBestValue());
    }

    public void printParameters() {

        String message = "\n";

        message += mso.getParameterString() + "\n";

        message += "Function parameters" + "\n";
        message += "*******************\n\n";

        message += objectiveFunction.getParameters();

        out(message);

        if (printToFile)
            infoOut.print(message);
    }

    public void printExperimentStatistics() {

        String message = "\n";
        message = "\nStatistics for instance " + currentInstance
                + " at function evaluation "
                + objectiveFunction.getNumberOfEvals() + "\n";
        message += "*****************************************************************************\n\n";
        message += objectiveFunction.getStatistics();
        message += "\n";
        message += "Number of Iterations: " + mso.getNumberOfIterations()
                + "\n";
        message += "Number of populations at end: " + mso.getNumberOfSwarms() + "\n";
        message += "Fevals per improvement: " + instFevalsPerImprovement + "\n";

        out(message);
        if (printToFile) {
            // infoOut.print( message );
        }
    }

    public void printRunStatistics() {

        String message = "\nRun Statistics\n";
        message += "**************\n";

        message += "NumberOfEvals:\t" + maxNumberOfEvals + "\n";
        message += "Number of function instances:\t"
                + numberOfFunctionInstances + "\n";

        double total = 0.0;
        double totalOfSquares = 0.0;
        int numberOfExpts = results.length;

        for (int k = 0; k < numberOfExpts; k++) {

            total += results[k];
            totalOfSquares += results[k] * results[k];
        }

        double average = total / numberOfExpts;
        double variance = (totalOfSquares / numberOfExpts)
                - (average * average);
        double correctedVariance = variance * (numberOfExpts)
                / (numberOfExpts - 1);
        double stdDev = Math.pow(correctedVariance, 0.5);
        double stdError = stdDev / Math.pow(numberOfExpts, 0.5);

        String summary = "\nAverage Value: " + average + "\n";
        summary += "Standard Error: " + stdError + "\n";

        // Calculate mean num iterations
        total = 0.0;
        totalOfSquares = 0.0;
        for (int k = 0; k < numberOfExpts; k++) {

            total += numIterations[k];
            totalOfSquares += numIterations[k] * numIterations[k];
        }
        average = total / numberOfExpts;
        variance = (totalOfSquares / numberOfExpts) - (average * average);
        correctedVariance = variance * (numberOfExpts) / (numberOfExpts - 1);
        stdDev = Math.pow(correctedVariance, 0.5);
        stdError = stdDev / Math.pow(numberOfExpts, 0.5);

        summary += "\nAverage iterations per instance: "
                + Math.round(Math.round(average)) + "\n";
        summary += "Standard Error: " + Math.round(Math.round(stdError)) + "\n";

        // calculate average of running averages
        total = 0.0;
        totalOfSquares = 0.0;
        for (int k = 0; k < numberOfExpts; k++) {

            total += fevalsPerImprovement[k];
            totalOfSquares += fevalsPerImprovement[k] * fevalsPerImprovement[k];
        }
        average = total / numberOfExpts;
        variance = (totalOfSquares / numberOfExpts) - (average * average);
        correctedVariance = variance * (numberOfExpts) / (numberOfExpts - 1);
        stdDev = Math.pow(correctedVariance, 0.5);
        stdError = stdDev / Math.pow(numberOfExpts, 0.5);
        summary += "\nAverage of f_evals per improvement: " + average + "\n";
        summary += "Standard Error: " + stdError + "\n";
        int fevalsPerIt = numberOfNeutralParticlesInSwarm
                + numberOfChargedParticlesInSwarm;
        summary += "\nAverage iterations per improvement: " + average
                / fevalsPerIt + "\n";

        String table = "\nInstance\t\tValue\t\t\t\t\tF_evals per improvement\t\t\tF_evals per improvement per iteration\n";

        for (int k = 0; k < numberOfFunctionInstances; k++) {
            table += k + "\t\t" + results[k] + "\t\t\t"
                    + fevalsPerImprovement[k] + "\t\t\t"
                    + fevalsPerImprovement[k] / fevalsPerIt + "\n";
        }

        message += table;

        message += "\nSummary\n";
        message += "*******\n";
        message += summary + "\n";

        out(message);
        if (printToFile) {
            infoOut.print(message);
        }
    }

    public void out(String message) {

        System.out.println(message);
    }

    public void closeOutput() {

        if (infoOut != null) {
            infoOut.close();
        }
        if (out != null) {
            out.close();
        }
    }

    public double getBestValue(int n) {

        return mso.getBestValue(n);
    }

    public int getNumberOfSwarms() {

        return numberOfSwarms;
    }

    public void setNumberOfSwarms(int n) {

        if (waiting && n > 0) {

            numberOfSwarms = n;
            setUpMSO();
        }
    }

    public int getNumberOfNeutralParticlesInSwarm() {

        return numberOfNeutralParticlesInSwarm;
    }

    public void setNumberOfNeutralParticlesInSwarm(int n) {

        if (waiting && n >= 0) {

            if (!(numberOfChargedParticlesInSwarm == 0 && n == 0)) {

                numberOfNeutralParticlesInSwarm = n;
                setUpMSO();
            }
        }
    }

    public int getNumberOfChargedParticlesInSwarm() {

        return numberOfChargedParticlesInSwarm;
    }

    public void setNumberOfChargedParticlesInSwarm(int n) {

        if (waiting && n >= 0) {

            if (!(numberOfNeutralParticlesInSwarm == 0 && n == 0)) {

                numberOfChargedParticlesInSwarm = n;
                setUpMSO();
            }
        }
    }

    public double getPositionComponent(int n, int k, int j) {

        return mso.getPositionComponent(n, k, j);
    }

    public double getFixedPointComponent(int n, int k, int j) {

        return mso.getFixedPointComponent(n, k, j);
    }

    public double getSwarmFixedPointComponent(int n, int j) {

        return mso.getSwarmFixedPointComponent(n, j);
    }

    public void setExclusionRadius(double d) {

        exclusionRadius = d;
        mso.setExclusionRadius(d);
    }

    public double getExclusionRadius() {

        return exclusionRadius;
    }

    public void setConvergenceRadius(double d) {

        convergenceRadius = d;
        mso.setConvergenceRadius(d);
    }

    public double getConvergenceRadius() {

        return convergenceRadius;
    }

    public double getPerceptionLimit() {

        return perceptionLimit;
    }

    public void setPerceptionLimit(double d) {

        perceptionLimit = d;
        mso.setPerceptionLimit(d);
    }

    public int getNumberOfDimensions() {

        return numberOfDimensions;
    }

    public void setNumberOfDimensions(int i) {

        /*
         * Dimensions must be greater than 1 for display
         */
        if (waiting && i > 1) {

            numberOfDimensions = i;

            setUpFunction();
            setUpMSO();
        }
    }

    public int getDynamicRange() {

        return dynamicRange;
    }

    public void setDynamicRange(int i) {

        if (waiting) {

            dynamicRange = i;

            setUpFunction();
            setUpMSO();
        }
    }

    public int getChangeFrequency() {

        return changeFrequency;
    }

    public void setChangeFrequency(int i) {

        if (waiting) {
            changeFrequency = i;
            setUpFunction();
            setUpMSO();
        }
    }

    public int getNumberOfAttractors() {

        return numberOfAttractors;
    }

    public void setNumberOfAttractors(int i) {

        if (waiting) {
            numberOfAttractors = i;
            setUpFunction();
            setUpMSO();
        }
    }

    public double getShiftSeverity() {

        return vlength;
    }

    public void setShiftSeverity(double d) {

        if (waiting) {
            vlength = d;
            setUpFunction();
            setUpMSO();
        }
    }

    public int getMaxNumberOfEvals() {

        return maxNumberOfEvals;
    }

    public void setMaxNumberOfEvals(int i) {

        if (waiting) {
            maxNumberOfEvals = i;
        }
    }

    public int getNumberOfFunctionInstances() {

        return numberOfFunctionInstances;
    }

    public void setNumberOfFunctionInstances(int i) {

        if (waiting) {
            numberOfFunctionInstances = i;
            setUpRun();
        }
    }

    public static void main(String[] args) {

        // System.out.println(System.currentTimeMillis()); System.exit(0);

        if (args.length == 0)
            new MSOApp();
        else if (args.length == 3) {
            try {
                int numberOfSwarms = Integer.parseInt(args[0]);
                int numberOfNeutralParticlesInEachSwarm = Integer
                        .parseInt(args[1]);
                int numberOfChargedParticlesInEachSwarm = Integer
                        .parseInt(args[2]);

                new MSOApp(numberOfSwarms, numberOfNeutralParticlesInEachSwarm,
                        numberOfChargedParticlesInEachSwarm);
            } catch (NumberFormatException e) {
                System.out
                        .println("java -cp classes MSOApp numSwarms numNeutral numCharged");
            }
        } else
            System.out
                    .println("java -cp classes MSOApp numSwarms numNeutral numCharged");
    }
}
