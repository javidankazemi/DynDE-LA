package App;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JTextField;
import javax.swing.JToggleButton;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class MSOAppGUI extends JFrame {

	MSOApp msoApp;

	JTextField charge, perception, exclusionRadius, convergenceRadius;

	JTextField numberOfSwarms, numberOfNeutralParticlesInSwarm,
			numberOfChargedParticlesInSwarm, numberOfDimensions, dynamicRange;

	JTextField numberOfAttractors, shiftSeverity, changeFrequency;

	JTextField  maxNumberOfEvals, numberOfFunctionInstances;

	public MSOAppGUI(MSOApp m) {

		super("Multi-Swarm Optimisation");
		msoApp = m;
		makeGUI();
	}

	public void makeGUI() {

		JPanel backPanel = new JPanel();
		backPanel.setLayout(new GridLayout(1, 0));
		backPanel.add(getControlPanel());
		getContentPane().add(backPanel);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		pack();
		setVisible(true);
	}

	public JPanel getControlPanel() {

		/*
		 * Search panel
		 */
		JPanel searchParamPanel = new JPanel();
		searchParamPanel.setBorder(new TitledBorder(new EtchedBorder(),
				"Search Parameters"));
		searchParamPanel.setLayout(new GridLayout(1, 1));

		JPanel searchParamLabelPanel = new JPanel();
		searchParamLabelPanel.setLayout(new GridLayout(5, 0));

		JPanel searchParamInputPanel = new JPanel();
		searchParamInputPanel.setLayout(new GridLayout(5, 0));

		searchParamPanel.add(searchParamLabelPanel);
		searchParamPanel.add(searchParamInputPanel);

		searchParamLabelPanel.add(new JLabel("Charge"));
		searchParamLabelPanel.add(new JLabel("Perception"));
		searchParamLabelPanel.add(new JLabel("Exclusion"));
		searchParamLabelPanel.add(new JLabel("Convergence"));
		searchParamLabelPanel.add(new JLabel("Change Randomisation Fraction"));

		charge = new JTextField(5);
		searchParamInputPanel.add(charge);
		charge.setText(Double.toString(msoApp.getCharge()));
		charge.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					double input = Double.valueOf(charge.getText())
							.doubleValue();
					msoApp.setCharges(input);
				} catch (NumberFormatException ex) {
				}
				charge.setText(Double.toString(msoApp.getCharge()));
			}
		});

		perception = new JTextField(5);
		searchParamInputPanel.add(perception);
		perception.setText(Double.toString(msoApp.getPerceptionLimit()));
		perception.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					double input = Double.valueOf(perception.getText())
							.doubleValue();
					msoApp.setPerceptionLimit(input);
				} catch (NumberFormatException ex) {
				}
				perception
						.setText(Double.toString(msoApp.getPerceptionLimit()));
			}
		});

		exclusionRadius = new JTextField(5);
		searchParamInputPanel.add(exclusionRadius);
		exclusionRadius.setText(Double.toString(msoApp.getExclusionRadius()));
		exclusionRadius.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					double input = Double.valueOf(exclusionRadius.getText())
							.doubleValue();
					msoApp.setExclusionRadius(input);
				} catch (NumberFormatException ex) {
				}
				exclusionRadius.setText(Double.toString(msoApp
						.getExclusionRadius()));
			}
		});

		convergenceRadius = new JTextField(5);
		searchParamInputPanel.add(convergenceRadius);
		convergenceRadius.setText(Double
				.toString(msoApp.getConvergenceRadius()));
		convergenceRadius.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					double input = Double.valueOf(convergenceRadius.getText())
							.doubleValue();
					msoApp.setConvergenceRadius(input);
				} catch (NumberFormatException ex) {
				}
				convergenceRadius.setText(Double.toString(msoApp
						.getConvergenceRadius()));
			}
		});


		

		/*
		 * Dynamic Panel
		 */
		JPanel dynamicParamPanel = new JPanel();
		dynamicParamPanel.setBorder(new TitledBorder(new EtchedBorder(),
				"Dynamic Parameters"));
		dynamicParamPanel.setLayout(new GridLayout(1, 1));

		JPanel dynamicParamLabelPanel = new JPanel();
		dynamicParamLabelPanel.setLayout(new GridLayout(5, 0));

		JPanel dynamicParamInputPanel = new JPanel();
		dynamicParamInputPanel.setLayout(new GridLayout(5, 0));

		dynamicParamPanel.add(dynamicParamLabelPanel);
		dynamicParamPanel.add(dynamicParamInputPanel);

		dynamicParamLabelPanel.add(new JLabel("Num Swarms"));
		dynamicParamLabelPanel
				.add(new JLabel("Num Neutral Particles In Swarm"));
		dynamicParamLabelPanel
				.add(new JLabel("Num Charged Particles In Swarm"));

		dynamicParamLabelPanel.add(new JLabel("Num Dimensions"));
		dynamicParamLabelPanel.add(new JLabel("Dynamic Range"));

		numberOfSwarms = new JTextField(5);
		dynamicParamInputPanel.add(numberOfSwarms);
		numberOfSwarms.setText(Integer.toString(msoApp.getNumberOfSwarms()));
		numberOfSwarms.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					int input = Integer.valueOf(numberOfSwarms.getText())
							.intValue();
					msoApp.setNumberOfSwarms(input);
				} catch (NumberFormatException ex) {
				}
				numberOfSwarms.setText(Integer.toString(msoApp
						.getNumberOfSwarms()));
			}
		});

		numberOfNeutralParticlesInSwarm = new JTextField(5);
		dynamicParamInputPanel.add(numberOfNeutralParticlesInSwarm);
		numberOfNeutralParticlesInSwarm.setText(Integer.toString(msoApp
				.getNumberOfNeutralParticlesInSwarm()));
		numberOfNeutralParticlesInSwarm.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					int input = Integer.valueOf(
							numberOfNeutralParticlesInSwarm.getText())
							.intValue();
					msoApp.setNumberOfNeutralParticlesInSwarm(input);
				} catch (NumberFormatException ex) {
				}
				numberOfNeutralParticlesInSwarm.setText(Integer.toString(msoApp
						.getNumberOfNeutralParticlesInSwarm()));
			}
		});

		numberOfChargedParticlesInSwarm = new JTextField(5);
		dynamicParamInputPanel.add(numberOfChargedParticlesInSwarm);
		numberOfChargedParticlesInSwarm.setText(Integer.toString(msoApp
				.getNumberOfChargedParticlesInSwarm()));
		numberOfChargedParticlesInSwarm.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					int input = Integer.valueOf(
							numberOfChargedParticlesInSwarm.getText())
							.intValue();
					msoApp.setNumberOfChargedParticlesInSwarm(input);
				} catch (NumberFormatException ex) {
				}
				numberOfChargedParticlesInSwarm.setText(Integer.toString(msoApp
						.getNumberOfChargedParticlesInSwarm()));
			}
		});

		numberOfDimensions = new JTextField(5);
		dynamicParamInputPanel.add(numberOfDimensions);
		numberOfDimensions.setText(Integer.toString(msoApp
				.getNumberOfDimensions()));
		numberOfDimensions.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					int input = Integer.valueOf(numberOfDimensions.getText())
							.intValue();
					msoApp.setNumberOfDimensions(input);
				} catch (NumberFormatException ex) {
				}
				numberOfDimensions.setText(Integer.toString(msoApp
						.getNumberOfDimensions()));
			}
		});

		dynamicRange = new JTextField(5);
		dynamicParamInputPanel.add(dynamicRange);
		dynamicRange.setText(Integer.toString(msoApp.getDynamicRange()));
		dynamicRange.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					int input = Integer.valueOf(dynamicRange.getText())
							.intValue();
					msoApp.setDynamicRange(input);
				} catch (NumberFormatException ex) {
				}
				dynamicRange
						.setText(Integer.toString(msoApp.getDynamicRange()));
			}
		});

		/*
		 * Button Panel
		 */
		JPanel buttonPanel = new JPanel();
		buttonPanel.setBorder(new TitledBorder(new EtchedBorder(), "Stop/Go"));
		buttonPanel.setLayout(new GridLayout(3, 0));

		JToggleButton displayButton = new JToggleButton("Display");
		buttonPanel.add(displayButton);
		displayButton.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					msoApp.setShowAnimation(true);
				} else {
					msoApp.setShowAnimation(false);
				}
			}
		});

		JToggleButton pauseButton = new JToggleButton("Pause");
		buttonPanel.add(pauseButton);
		pauseButton.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					msoApp.setPause(true);
				} else {
					msoApp.setPause(false);
				}
			}
		});

		JToggleButton startButton = new JToggleButton("Start/Stop");
		buttonPanel.add(startButton);
		startButton.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					msoApp.start();
				} else {
					msoApp.close();
				}
			}
		});

		/*
		 * Slider Panel
		 */
		JPanel sliderPanel = new JPanel();
		sliderPanel.setLayout(new GridLayout(4, 0));

		JLabel speedLabel = new JLabel("Animation Speed");
		sliderPanel.add(speedLabel);

		final JSlider speedSlider = new JSlider(0, 1000, 2);
		speedSlider.setInverted(true);
		sliderPanel.add(speedSlider);
		speedSlider.addChangeListener(new ChangeListener() {

			public void stateChanged(ChangeEvent e) {

				//  Between 0 and 1000 msecs
				long value = speedSlider.getValue();
				msoApp.setAnimationSpeed(value);
			}
		});

		JLabel magnificationLabel = new JLabel("Magnification");
		sliderPanel.add(magnificationLabel);

		final JSlider magnificationSlider = new JSlider(-10, 10, 0);
		magnificationSlider.setInverted(true);
		magnificationSlider.setMajorTickSpacing(1);
		magnificationSlider.setSnapToTicks(true);
		sliderPanel.add(magnificationSlider);
		magnificationSlider.addChangeListener(new ChangeListener() {

			public void stateChanged(ChangeEvent e) {

				double value = Math.pow(2, magnificationSlider.getValue());
				msoApp.setMagnification(value);
			}
		});

		/*
		 * Dimension panel
		 */
		JPanel dimensionLabelPanel = new JPanel();
		dimensionLabelPanel.setLayout(new GridLayout(2, 0));
		dimensionLabelPanel.add(new JLabel("x axis"));
		dimensionLabelPanel.add(new JLabel("y axis"));

		JPanel dimensionTextPanel = new JPanel();
		dimensionTextPanel.setLayout(new GridLayout(2, 0));

		final JTextField xAxisTextField = new JTextField(5);
		dimensionTextPanel.add(xAxisTextField);
		xAxisTextField.setText(Integer.toString(msoApp.getXAxis()));
		xAxisTextField.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					int input = Integer.valueOf(xAxisTextField.getText())
							.intValue();
					msoApp.setXAxis(input);
				} catch (NumberFormatException ex) {
				}
				xAxisTextField.setText(Integer.toString(msoApp.getXAxis()));
			}
		});

		final JTextField yAxisTextField = new JTextField(5);
		dimensionTextPanel.add(yAxisTextField);
		yAxisTextField.setText(Integer.toString(msoApp.getYAxis()));
		yAxisTextField.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					int input = Integer.valueOf(yAxisTextField.getText())
							.intValue();
					msoApp.setYAxis(input);
				} catch (NumberFormatException ex) {
				}
				yAxisTextField.setText(Integer.toString(msoApp.getYAxis()));
			}
		});

		JPanel dimensionPanel = new JPanel();
		dimensionPanel.setLayout(new GridLayout(1, 1));
		dimensionPanel.add(dimensionLabelPanel);
		dimensionPanel.add(dimensionTextPanel);

		JPanel controls = new JPanel();
		controls.setBorder(new TitledBorder(new EtchedBorder(), "Display"));
		controls.setLayout(new GridLayout(2, 0));
		controls.add(sliderPanel);
		//controls.add( buttonPanel );
		controls.add(dimensionPanel);

		/*
		 * Function panel
		 */
		JPanel functionParamPanel = new JPanel();
		functionParamPanel.setBorder(new TitledBorder(new EtchedBorder(),
				"Function Parameters"));
		functionParamPanel.setLayout(new GridLayout(1, 1));

		JPanel functionParamLabelPanel = new JPanel();
		functionParamLabelPanel.setLayout(new GridLayout(4, 0));

		JPanel functionParamInputPanel = new JPanel();
		functionParamInputPanel.setLayout(new GridLayout(4, 0));

		functionParamPanel.add(functionParamLabelPanel);
		functionParamPanel.add(functionParamInputPanel);

		functionParamLabelPanel.add(new JLabel("Modal Severity"));
		functionParamLabelPanel.add(new JLabel("Shift Severity"));
		functionParamLabelPanel.add(new JLabel("Change Frequency"));

		numberOfAttractors = new JTextField(5);
		functionParamInputPanel.add(numberOfAttractors);
		numberOfAttractors.setText(Integer.toString(msoApp
				.getNumberOfAttractors()));
		numberOfAttractors.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					int input = Integer.valueOf(numberOfAttractors.getText())
							.intValue();
					msoApp.setNumberOfAttractors(input);
				} catch (NumberFormatException ex) {
				}
				numberOfAttractors.setText(Integer.toString(msoApp
						.getNumberOfAttractors()));
			}
		});

		shiftSeverity = new JTextField(5);
		functionParamInputPanel.add(shiftSeverity);
		shiftSeverity.setText(Double.toString(msoApp.getShiftSeverity()));
		shiftSeverity.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					double input = Double.valueOf(shiftSeverity.getText())
							.doubleValue();
					msoApp.setShiftSeverity(input);
				} catch (NumberFormatException ex) {
				}
				shiftSeverity.setText(Double
						.toString(msoApp.getShiftSeverity()));
			}
		});

		changeFrequency = new JTextField(5);
		functionParamInputPanel.add(changeFrequency);
		changeFrequency.setText(Integer.toString(msoApp.getChangeFrequency()));
		changeFrequency.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					int input = Integer.valueOf(changeFrequency.getText())
							.intValue();
					msoApp.setChangeFrequency(input);
				} catch (NumberFormatException ex) {
				}
				changeFrequency.setText(Integer.toString(msoApp
						.getChangeFrequency()));
			}
		});

		/*
		 * Experiment panel
		 */
		JPanel experimentParamPanel = new JPanel();
		experimentParamPanel.setBorder(new TitledBorder(new EtchedBorder(),
				"Experiment Parameters"));
		experimentParamPanel.setLayout(new GridLayout(1, 1));

		JPanel experimentParamLabelPanel = new JPanel();
		experimentParamLabelPanel.setLayout(new GridLayout(4, 0));

		JPanel experimentParamInputPanel = new JPanel();
		experimentParamInputPanel.setLayout(new GridLayout(4, 0));

		experimentParamPanel.add(experimentParamLabelPanel);
		experimentParamPanel.add(experimentParamInputPanel);

	
		experimentParamLabelPanel.add(new JLabel("Evals"));
		experimentParamLabelPanel.add(new JLabel("Instances"));

		maxNumberOfEvals = new JTextField(5);
		experimentParamInputPanel.add(maxNumberOfEvals);
		maxNumberOfEvals
				.setText(Integer.toString(msoApp.getMaxNumberOfEvals()));
		maxNumberOfEvals.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					int input = Integer.valueOf(maxNumberOfEvals.getText())
							.intValue();
					msoApp.setMaxNumberOfEvals(input);
				} catch (NumberFormatException ex) {
				}
				maxNumberOfEvals.setText(Integer.toString(msoApp
						.getMaxNumberOfEvals()));
			}
		});

		numberOfFunctionInstances = new JTextField(5);
		experimentParamInputPanel.add(numberOfFunctionInstances);
		numberOfFunctionInstances.setText(Integer.toString(msoApp
				.getNumberOfFunctionInstances()));
		numberOfFunctionInstances.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					int input = Integer.valueOf(
							numberOfFunctionInstances.getText()).intValue();
					msoApp.setNumberOfFunctionInstances(input);
				} catch (Exception ex) {
				}
				numberOfFunctionInstances.setText(Integer.toString(msoApp
						.getNumberOfFunctionInstances()));
			}
		});


		/*
		 * Control Panel
		 */
		JPanel controlPanel = new JPanel();
		controlPanel.setLayout(new GridLayout(3, 3));
		controlPanel.add(searchParamPanel);
		controlPanel.add(dynamicParamPanel);
		controlPanel.add(controls);
		controlPanel.add(buttonPanel);
		controlPanel.add(functionParamPanel);
		controlPanel.add(experimentParamPanel);

		return controlPanel;
	}

	public void update() {

		charge.setText(Double.toString(msoApp.getCharge()));
		perception.setText(Double.toString(msoApp.getPerceptionLimit()));
		exclusionRadius.setText(Double.toString(msoApp.getExclusionRadius()));
		convergenceRadius.setText(Double
				.toString(msoApp.getConvergenceRadius()));


		numberOfSwarms.setText(Integer.toString(msoApp.getNumberOfSwarms()));
		numberOfNeutralParticlesInSwarm.setText(Integer.toString(msoApp
				.getNumberOfNeutralParticlesInSwarm()));
		numberOfChargedParticlesInSwarm.setText(Integer.toString(msoApp
				.getNumberOfChargedParticlesInSwarm()));
		numberOfDimensions.setText(Integer.toString(msoApp
				.getNumberOfDimensions()));
		dynamicRange.setText(Integer.toString(msoApp.getDynamicRange()));

		numberOfAttractors.setText(Integer.toString(msoApp
				.getNumberOfAttractors()));
		shiftSeverity.setText(Double.toString(msoApp.getShiftSeverity()));
		changeFrequency.setText(Integer.toString(msoApp.getChangeFrequency()));


		maxNumberOfEvals
				.setText(Integer.toString(msoApp.getMaxNumberOfEvals()));
		numberOfFunctionInstances.setText(Integer.toString(msoApp
				.getNumberOfFunctionInstances()));
	}

	public static void main(String[] args) {

	}
}
