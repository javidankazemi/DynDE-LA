package App;

import Utilities.Application;
import Functions.*;

public class FunctionApp extends Application {

	/*
	 * (non-Javadoc)
	 * 
	 * @see Utilities.Application#close()
	 */
	public void close() {

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see Utilities.Application#inform(int, double)
	 */
	public void inform(int i, double d) {

		System.out.println(d);
	}

	public static void main(String[] args) {

		Application app = new FunctionApp();
		String name = "Cone";
		int dims = 5;
		long seed = System.currentTimeMillis();
		int range = 100;
		double tTheta = 1.0;
		ObjectiveFunction func = new Cone(name, dims, tTheta, app);
		double norm = Math.pow(dims, 0.5);
		double[] x = new double[dims];
			for (int i = 0; i < dims; i++)
				x[i] = 1.0E-180/norm;
		
		func.getValue(x);

	}
}
