package App;

import Utilities.Loop;

/**
 * This class starts and stops the main update loop. The loop runs within its
 * own thread.
 * 
 * @version 1.0 May 2003
 * @author Tim Blackwell
 *  
 */
public class MainLoop extends Loop {

    protected MSOApp msoApp;

    protected int maxIterations;

    protected int counter = 0;

    public MainLoop(MSOApp m, int i) {

        this.msoApp = m;
        maxIterations = i;
    }

    public void run() {

        super.run();
    }

    public void update() {

        counter++;

        msoApp.update();

        try {
            if (counter == maxIterations) {
                stopLoop();
            }

        } catch (Exception e) {
        }
    }

    public void stopLoop() {

        counter = 0;
        super.stopLoop();
    }

    public int getCounter() {
        return counter;
    }
}
