package App;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.StringTokenizer;

import javax.swing.JFrame;

public class Plotter extends JFrame{

    private int width;
    private int height;

    private double xMin;
    private double yMin;
    private double xMax;
    private double yMax;    

    private double xAxisMin;
    private double yAxisMin;
    private double xAxisMax;
    private double yAxisMax;    

    private double bottomMargin;
    private double topMargin;
    private double leftMargin;
    private double rightMargin;

    private double xDrawingOrigin;
    private double yDrawingOrigin;

    private Graphics2D g2d;

    final int XCOORD = 0;
    final int YCOORD = 1;

    private double[][] xData;
    private double[][] yData;

    private int numberOfDataSets;
    private int numberOfCoordinatesPerSet;

    private double XTickIncr = 1.0;
    private double YTickIncr = 1.0;

    private int skip = 1;

    private boolean OKToPlot = false;

    private String dataSet = "";

    public Plotter( File file ){
	
	super( "Plotter" );
	setUp();

	dataSet = file.getName();
	getData( file );
    }

    public Plotter( String fileName ){

	super( "Plotter" );
	setUp();

	File file = new File( fileName );
	dataSet = fileName;

	getData( file );
    }

    private void setUp(){

	Toolkit toolkit = getToolkit();
	Dimension screenSize = toolkit.getScreenSize();
	
	//  set width to 0.9 height of screen
	width = (int) ( screenSize.getHeight() * 0.9 );
	height = width;

	xMin = 0.0;
	xMax = 100.0;
	yMin = 0.0;
	yMax = 100.0;

	bottomMargin = height * 0.2;
	topMargin = height * 0.3;
	leftMargin = width * 0.2;
	rightMargin = width * 0.2;

	xDrawingOrigin = leftMargin;
	yDrawingOrigin = height - bottomMargin;

	setBounds( (int)(screenSize.getWidth() - width), 0, width, height );
	setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
	setVisible( true );

    }

    public void clear(){

	g2d.setColor( Color.black);
	g2d.fill( new Rectangle( 0,0,width,height ));
    }

    public void paint( Graphics gr ){

	g2d = (Graphics2D)gr;
	clear();

	/*
	 *  Background
	 */
//  	g2d.setColor( Color.red );

	/*
	 *  
	 */
	double r = 2.0;
	int R = 255;
	int G = 0;
	int B = 0;

	if ( OKToPlot ){
	    //caption();
	    drawAxes();
	    plotData();
	}

    }

    private void caption(){

	g2d.setColor( Color.white );
	StringTokenizer tokenizer = new StringTokenizer( dataSet, "." );
	String name = tokenizer.nextToken();
	tokenizer = new StringTokenizer( name, "_" );
	StringBuffer sBuff = new StringBuffer();
	while( tokenizer.hasMoreTokens() ){
	    sBuff.append( tokenizer.nextToken() + " " );
	}
	name = sBuff.toString();
	g2d.drawString( name, (float)(width-rightMargin-width/10), (float)(topMargin+height/20) );
    }

    private void setPlotData( double[][] x, double[][] y ){

	xData = new double[ numberOfDataSets] [ numberOfCoordinatesPerSet ];
	yData = new double[ numberOfDataSets ][ numberOfCoordinatesPerSet ];
	for ( int i = 0; i < numberOfDataSets; i++ ){

	    xData[ i ] = new double[ x[ i ].length ];
	    yData[ i ] = new double[ y[ i ].length ];
	    System.arraycopy( x[ i ], 0, xData[ i ], 0, numberOfCoordinatesPerSet );
	    System.arraycopy( y[ i ], 0, yData[ i ], 0, numberOfCoordinatesPerSet );
	}
    }

    private void plotData(){

	g2d.setColor( Color.red );

	boolean joinUp = true;
	for ( int i = 0; i < numberOfDataSets; i++ ){
	    int j = 0;
	    for ( ; j < numberOfCoordinatesPerSet; j += skip ){

		//drawRectangle( xData[ i ][ j ], yData[ i ][ j ] );
		//drawCross( xData[ i ][ j ], yData[ i ][ j ] );
		drawEllipse( xData[ i ][ j ], yData[ i ][ j ] );

		if ( joinUp && (j > 0) ){
		drawLine( xData[ i ][ j-skip ], yData[ i ][ j-skip], xData[ i ][ j ], yData[ i ][ j ] );
		}
	    }


	    //  Plot last point	
	    if ( j != xData[ i ].length - 1 ){
		j = xData[ i ].length - 1;
		//drawCross( xData[ i ][ j ], yData[ i ][ j ] );
		drawEllipse( xData[ i ][ j ], yData[ i ][ j ] );
		if ( joinUp ){
		    drawLine( xData[ i ][ j-skip ], yData[ i ][ j-skip], xData[ i ][ j ], yData[ i ][ j ] );
		}
	    }
	    //  Label data set
	    String label = "";
	    float xLabel = (float)( getX( xData[ i ][ j ]) + 10 );
	    float yLabel = (float)( getY( yData[ i ] [ j ] )  );
	    if ( i == 0 )
		label = "mCPSO";
	    if ( i == 1 ){
		label = "mQSO";
		yLabel -= 10;
	    }
	    if ( i == 3 ){
		label = "Multi-QSO";
		yLabel += 10;
	    }
	    

	    g2d.drawString( label, xLabel, yLabel );

	}
    }

    private void drawLine( double xL, double yL, double xR, double yR ){

	double pL = getX( xL );
	double qL = getY( yL );
	double pR = getX( xR );
	double qR = getY( yR );
	Line2D.Double line = new Line2D.Double( pL, qL, pR, qR );
	g2d.draw( line );
    }

    private void drawRectangle( double x, double y ){

	double rectangleWidth = 5.0;
	double rectangleHeight = 5.0;

	double p = getX( x )- rectangleWidth/2;
	double q = getY( y )- rectangleHeight/2;

	if ( p >= leftMargin && p <= width-rightMargin && q >= bottomMargin && q <= height-topMargin){

	    Rectangle2D.Double rectangle = new Rectangle2D.Double( p, q, rectangleWidth, rectangleHeight);
	    g2d.draw( rectangle );
	}
    }

    private void drawEllipse( double x, double y ){

	double ellipseHeight = 4;
	double ellipseWidth = 4;

	double p = getX( x ) - ellipseWidth/2;
	double q = getY( y ) - ellipseHeight/2;
	g2d.fill( new Ellipse2D.Double( p, q, ellipseWidth, ellipseHeight ) );
    }

    private void drawCross( double x, double y ){

	double halfLength = 2;
	double p = getX( x );
	double q = getY( y );
	g2d.draw( new Line2D.Double( p - halfLength, q, p + halfLength, q ) );
	g2d.draw( new Line2D.Double( p, q - halfLength, p, q + halfLength) );

    }
		      


    private void drawAxes(){

	g2d.setColor( Color.white );

	drawLine( xAxisMin, yAxisMin, xAxisMax, yAxisMin );
	drawLine( xAxisMin, yAxisMin, xAxisMin, yAxisMax );

	java.text.DecimalFormat decimalFormat = new java.text.DecimalFormat( "0.##E0" );
	decimalFormat.setMinimumFractionDigits( 1 );

	for ( double d  = xAxisMin; d <= xAxisMax; d += XTickIncr ){

	    g2d.draw( new Line2D.Double( getX( d ), getY( yAxisMin ), getX( d ), getY( yAxisMin ) + 5 ) );		

	    float xPosOfString = (float)getX( d ) - 15;
	    float yPosOfString = (float)getY( yAxisMin ) + 20;
	    if ( d == 0 ){
		g2d.drawString( "0", xPosOfString+15-2, yPosOfString );
	    }
	    else{
		g2d.drawString( decimalFormat.format(d), xPosOfString, yPosOfString );
	    }

	}

	float xPosOfLabel = (float)getX( (xAxisMax - xAxisMin) / 3 );
	float yPosOfLabel = (float)getY( yAxisMin ) + 40;
	g2d.drawString( "Number of Function Evaluations",  xPosOfLabel, yPosOfLabel );

	for ( double d = yAxisMin; d <= yAxisMax; d += YTickIncr ){

	    g2d.draw( new Line2D.Double( getX(xAxisMin), getY(d), getX(xAxisMin)-5, getY(d) ) );	

	    float xPosOfString = (float)getX( xAxisMin ) - 40;
	    float yPosOfString = (float)getY( d ) + 4;

	    if ( d > 0.001 && d < 1000 ) {
		decimalFormat = new java.text.DecimalFormat("###.0##");
	    }
	    if ( d == 0 ){
		g2d.drawString( "0", xPosOfString, yPosOfString );
	    }
	    else{
		g2d.drawString( decimalFormat.format(d), xPosOfString, yPosOfString );
	    }

	}

	xPosOfLabel = (float)getX( xAxisMin ) - 80;
	yPosOfLabel = (float)getY( (yAxisMax - yAxisMin)/2 );
	g2d.drawString( "Offline" , xPosOfLabel, yPosOfLabel );
	g2d.drawString( "Error", xPosOfLabel, yPosOfLabel + 20 );
    }



    private double getX( double rawX ){

	double xScaleFactor = ( width - leftMargin - rightMargin ) / (xAxisMax - xAxisMin);
	return xDrawingOrigin + xScaleFactor * ( rawX - xAxisMin );
    }

    private double getY( double rawY ){

	double yScaleFactor = ( height - topMargin - bottomMargin ) / (yAxisMax - yAxisMin);	
	return yDrawingOrigin - yScaleFactor * ( rawY - yAxisMin );
    }


    public void setXAxisMin( double d ){

	xAxisMin = d;
    }

    public void setYAxisMin( double d ){

	yAxisMin = d;
    }

    public void setXAxisMax( double d ){

	xAxisMax = d;
    }

    public void setYAxisMax( double d ){

	yAxisMax = d;
    }

    public void setXTickIncr( int i ){

	XTickIncr = i;
    }

    public void setYTickIncr(){

	int numberOfTicks = (int)((yAxisMax - yAxisMin ) / YTickIncr );
	while ( numberOfTicks > 10 ){
	    YTickIncr *= 10.0;
	    numberOfTicks = (int)((yAxisMax - yAxisMin ) / YTickIncr );
	}
	while ( numberOfTicks < 1 ){
	    YTickIncr /= 10.0;
	    numberOfTicks = (int)((yAxisMax - yAxisMin ) / YTickIncr );
	}
	if ( numberOfTicks < 5 && numberOfTicks > 2 ) {
	    YTickIncr /= 2;
	}
	else if ( numberOfTicks <= 2 ) {
	    YTickIncr /= 10;
	}
    }

    public void setSkip( int i ){
	
	skip = i;
    }

    public void getData( File file ){


	//File file = new File( fileName );

	//dataSet = fileName;

	numberOfDataSets = 2;
	numberOfCoordinatesPerSet = 50;

	double[][] x = new double[ numberOfDataSets ][ numberOfCoordinatesPerSet ];
	double[][] y = new double[ numberOfDataSets ][ numberOfCoordinatesPerSet ];

	try{
	    BufferedReader in = new BufferedReader( new FileReader( file ) ) ;

	    String dataString = "";

	    for ( int i = 0; i < numberOfDataSets; i++ ){

		int next = 0;

		for ( int j = 0; j < numberOfCoordinatesPerSet; j++ ){

		    dataString = in.readLine();

		    StringTokenizer st = new StringTokenizer( dataString, "\t" );

		    while( st.hasMoreTokens() ){

			double nextDouble = 0.0;
			try{
			    nextDouble = Double.parseDouble( st.nextToken() );
			}
			catch( NumberFormatException nfe ){
			    System.out.println( "Couldn't read number. Setting to 0.0");
			}
			int index = next / 2;
			if ( next % 2 == 0 ){
			    x[ i ][ index ] = nextDouble;
			}
			else{
			    y[ i ][ index ] = nextDouble;
			}
			next++;
		    }
		}
	    }

	    xAxisMin = 0.0;
	    yAxisMin = 0.0;

	    xAxisMax = 500000;
	    yAxisMax = 30;

	    setYTickIncr();
	    setSkip( 1 );
	    setXTickIncr( 100000 );

	    setPlotData( x, y );
	    OKToPlot = true;
	    repaint();

	}
	catch( IOException ioe  ){

	    System.out.println( "Error reading file" );
	    System.exit( 0 );
	}

    }


    public static void main( String[] args ){

	Plotter plotter = new Plotter( args[ 0 ] );
	//plotter.getData( args[0] );
    }

}
