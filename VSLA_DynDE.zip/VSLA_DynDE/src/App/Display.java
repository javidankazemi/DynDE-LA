package App;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;

import javax.swing.JFrame;

import Functions.ObjectiveFunction;
import Functions.PeakFunction;
import MultiSwarm.MSO;

public class Display extends JFrame {

	private int width;

	private int height;

	private int[] origin = new int[2];

	private int xAxis = 0;

	private int yAxis = 1;

	private double magnification = 1.0;

	private MSOApp msoApp;

	private MSO mso;

	private ObjectiveFunction objectiveFunction;

	private Graphics2D g2d;

	//  Radius of particles, peak size and attractor box length
	private double r = 4;

	public Display(int w, int h, ObjectiveFunction oF, MSO mso, int x, int y) {

		super("Display");

		objectiveFunction = oF;
		this.mso = mso;

		width = w;
		height = h;

		origin[0] = (int) (width / 2);
		origin[1] = (int) (height / 2);

		xAxis = x;
		yAxis = y;

		setSize(width, height);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setVisible(true);
	}

	public Display(ObjectiveFunction oF, MSO mso, int x, int y) {

		super("Display");

		objectiveFunction = oF;
		this.mso = mso;

		Toolkit toolkit = getToolkit();
		Dimension screenSize = toolkit.getScreenSize();

		//  set width to 0.95 height of screen
		width = (int) (screenSize.getHeight() * 0.95);
		height = width;

		origin[0] = (int) (width / 2);
		origin[1] = (int) (height / 2);

		xAxis = x;
		yAxis = y;

		setBounds((int) (screenSize.getWidth() - width), 0, width, height);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setVisible(true);
	}

	public void paint(Graphics gr) {

		g2d = (Graphics2D) gr;
		clear();

		/*
		 * Background
		 */
		//  	g2d.setColor( Color.red );

		/*
		 * Scale factor so that dynamic range is half width
		 */
		int dynamicRange = (int) mso.getDynamicRange();
		int scaleFactor = (int) (0.5 * width / dynamicRange);

		/*
		 * Magnification
		 */
		scaleFactor = (int) (scaleFactor / magnification);

		/*
		 * Particle positions
		 */
		int R = 255;
		int G = 0;
		int B = 0;

		/*
		 * Dimensions of space
		 */
		int dimension = mso.getNumberOfDimensions();

		int numberOfSwarms = mso.getNumberOfSwarms();

		for (int n = 0; n < numberOfSwarms; n++) {

			if (numberOfSwarms > 1) {

				R = (int) (((numberOfSwarms - 1 - n) * 255) / (numberOfSwarms - 1));
				B = 255 - R;
				//G = 2 * B + ((int)( B / 128.0 ) * ( 510 - 4 * B ));
			}
			g2d.setColor(new Color(R, G, B));

			int numberOfParticlesInSwarm = mso.getNumberOfParticlesInSwarm(n);

			double X;
			double Y;
			for (int k = 0; k < numberOfParticlesInSwarm; k++) {

				//  particle positions
				X = scaleFactor * mso.getPositionComponent(n, k, xAxis)
						+ origin[0];

				Y = origin[1];
				if (dimension > 1) {
					Y = origin[1] - scaleFactor
							* mso.getPositionComponent(n, k, yAxis);
				}

				g2d.fill(new Ellipse2D.Double(X - r, Y - r, 2 * r, 2 * r));

				//  best positions
				X = scaleFactor * mso.getFixedPointComponent(n, k, xAxis)
						+ origin[0];

				Y = origin[1];
				if (dimension > 1) {
					Y = origin[1] - scaleFactor
							* mso.getFixedPointComponent(n, k, yAxis);
				}

				g2d.draw(new Ellipse2D.Double(X - r, Y - r, 2 * r, 2 * r));
			}

			X = scaleFactor * mso.getSwarmFixedPointComponent(n, xAxis)
					+ origin[0];

			Y = origin[1];
			if (dimension > 1) {
				Y = origin[1] - scaleFactor
						* mso.getSwarmFixedPointComponent(n, yAxis);
			}
			g2d
					.draw(new Rectangle2D.Double(X - 2 * r, Y - 2 * r, 4 * r,
							4 * r));
			g2d.drawString(Integer.toString(n), (int) (X + 2 * r + 2), (int) (Y
					+ 2 * r + 6));

		}

		/*
		 * Draw box around origin at + and - 0.5 dynamic range N.B. Display
		 * width is defined as twice dynamic range ScaleFactor scales postions
		 * accordingly
		 */
		  	g2d.setColor( Color.white );
		  	int xTopLeft = (int)(origin[0] - 0.5 * scaleFactor * dynamicRange );
		  	int yTopLeft = (int)(origin[1] - 0.5 * scaleFactor * dynamicRange );
		  	int xTopRight = xTopLeft + scaleFactor * dynamicRange;
		  	int yTopRight = yTopLeft;
		  	int xBottomLeft = xTopLeft;
		  	int yBottomLeft = yTopLeft + scaleFactor * dynamicRange;
		  	int xBottomRight = xTopRight;
		  	int yBottomRight = yBottomLeft;
		  	g2d.drawLine( xTopLeft, yTopLeft, xTopRight, yTopRight );
		  	g2d.drawLine( xTopLeft, yTopLeft, xBottomLeft, yBottomLeft );
		  	g2d.drawLine( xTopRight, yTopRight, xBottomRight, yBottomRight );
		  	g2d.drawLine( xBottomLeft, yBottomLeft, xBottomRight, yBottomRight );
		/*
		 * Attractors
		 */
		double[][] attractors = objectiveFunction.getAttractors();
		g2d.setColor(Color.green);
		for (int n = 0; n < attractors.length; n++) {
			int X = (int) (scaleFactor * attractors[n][xAxis] + origin[0]);

			int Y = origin[1];
			if (dimension > 1) {
				Y = (int) (origin[1] - scaleFactor * attractors[n][yAxis]);
			}
			int crossWidth = (int) (2 * r);
			g2d.drawLine(X - crossWidth, Y, X + crossWidth, Y);
			g2d.drawLine(X, Y - crossWidth, X, Y + crossWidth);
			g2d.drawString(Integer.toString(n), X + 2, Y - 2);
		}
		if (objectiveFunction instanceof PeakFunction) {
			int maxPeak = ((PeakFunction) objectiveFunction).getMaximumPeak();

			int X = (int) (scaleFactor * attractors[maxPeak][xAxis] + origin[0]);
			int Y = origin[1];
			if (dimension > 1) {
				Y = (int) (origin[1] - scaleFactor * attractors[maxPeak][yAxis]);
			}
			int crossWidth = (int) (2 * r);
			g2d.drawLine(X - crossWidth, Y - crossWidth, X + crossWidth, Y
					+ crossWidth);
			g2d.drawLine(X - crossWidth, Y + crossWidth, X + crossWidth, Y
					- crossWidth);
		}
	}

	public void setAxes(int x, int y) {

		xAxis = x;
		yAxis = y;
	}

	public int getXAxis() {

		return xAxis;
	}

	public void setXAxis(int i) {

		xAxis = i;
	}

	public int getYAxis() {

		return yAxis;
	}

	public void setYAxis(int i) {

		yAxis = i;
	}

	public void clear() {

		g2d.setColor(Color.black);
		g2d.fill(new Rectangle(0, 0, width, height));
	}

	public void setMagnification(double d) {
		magnification = d;
	}

	public void setMSO(MSO m) {
		mso = m;
	}

	public void setObjectiveFunction(ObjectiveFunction o) {
		objectiveFunction = o;
	}

}
