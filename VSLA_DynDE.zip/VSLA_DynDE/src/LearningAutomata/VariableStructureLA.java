/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package LearningAutomata;

import java.util.Random;
/**
 *
 * @author Amir Ehsan Ranginkaman <aeranginkaman@gmail.com>
 */
public class VariableStructureLA {
    protected double[] p;     //probabilties of action
    protected double a;       //reward rate
    protected double b;       //penalty rate
    protected int selected_action;
    protected int nAction;
    protected Random r;
    public VariableStructureLA(int nAction, double a, double b, long seed){
        this.a = a;
        this.b = b;
        this.nAction = nAction;
        
        p = new double[nAction];
        for(int i=0;i<nAction; i++){
            p[i] = (double)1/nAction;
        }
        r = new Random(seed);
                
    }
    
    public void resetLA() {
        for (int i = 0; i < nAction; i++) {
            p[i] = (double) 1 / nAction;
        }
    }
    
    public int select_action() {
        double randomNumber = r.nextDouble();
        double sumP = 0.0;

        for (int i = 0; i < nAction; i++) {
            sumP += p[i];
            if (randomNumber <= sumP) {
                selected_action = i;
                return i;
            }
        }
        return selected_action;
    }


    public void update(double beta) {
        if ((int) beta == 0) {
            for (int i = 0; i < nAction; i++) {
                if (i == selected_action) {
                    p[i] += a * (1 - p[i]);
                } else {
                    p[i] = (1 - a) * p[i];
                }
            }
        } else if ((int) beta == 1) {
            for (int i = 0; i < nAction; i++) {
                if (i == selected_action) {
                    p[i] = (1 - b) * p[i];
                } else {
                    p[i] = b / (nAction - 1) + (1 - b) * p[i];
                }
            }

        }

    }
    
    public void resetAction(int j){
        
        if(p[j] > (double)1/nAction){
            double diff = p[j] - (double)1/nAction;
            
            for(int i=0; i<nAction; i++){
                if(i == j){
                    p[i] = (double)1/nAction;
                }else{
                    p[i] += (double)diff/(nAction-1);
                }
            }
        }else{
             double diff = (double)1/nAction - p[j];
            
            for(int i=0; i<nAction; i++){
                if(i == j){
                    p[i] = (double)1/nAction;
                }else{
                    p[i] -= (double)diff/(nAction-1);
                }
            }           
        }
        
    }
    
    public void resetAction(int j, double pj){
        
        if(p[j] > pj){
            double diff = p[j] - pj;
            
            for(int i=0; i<nAction; i++){
                if(i == j){
                    p[i] = pj;
                }else{
                    p[i] += (double)diff/(nAction-1);
                }
            }
        }else{
             double diff = pj - p[j];
            
            for(int i=0; i<nAction; i++){
                if(i == j){
                    p[i] = pj;
                }else{
                    p[i] -= (double)diff/(nAction-1);
                }
            }           
        }
        
    }
    
    
    //public abstract void update(double beta, double epsilon);
    //public abstract void success();
    //public abstract void failure();
    

    
}
