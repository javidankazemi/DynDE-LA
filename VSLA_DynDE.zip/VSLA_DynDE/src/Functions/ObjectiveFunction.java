package Functions;

import Utilities.*;

public abstract class ObjectiveFunction {

	String name;

	Application application;

	public ObjectiveFunction(String s, Application a) {
		name = s;
		application = a;
	}

	public abstract double getValue(double[] arg);

	public abstract double[][] getAttractors();

//	public abstract void randomiseAttractors(int dynamicRange,
//			double minimumAttractorSeparation);

	//public abstract void randomiseAttractorValues();

	//public abstract void setAttractorValues(double[] values);

	public abstract void print();

	public abstract int getNumberOfEvals();

	public abstract String getStatistics();

	public abstract String getParameters();

	public String getName() {

		return name;
	}
}
