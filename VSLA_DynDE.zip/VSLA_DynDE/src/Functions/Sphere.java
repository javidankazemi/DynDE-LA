package Functions;

import java.util.*;

import Utilities.Application;

public class Sphere extends ObjectiveFunction {

	double[] attractor;

	double height;

	int dynamicRange;

	double maximumHeight = 100.0;

	int numberOfDimensions;

	int frequency;

	Random attrRandom = new Random(20052003);

	Random heightRandom = new Random(1565924878);

	double bestValueSoFar = Double.MAX_VALUE;

	int numberOfFunctionEvaluations = 0;

	int maxNumberOfEvals = 500000;

	public Sphere(String name, double[] a, int dims, int freq, double h,
			int range, int maxEvals, Application app) {

		super(name, app);

		attractor = a;
		numberOfDimensions = dims;
		frequency = freq;
		height = h;
		dynamicRange = range;
		maxNumberOfEvals = maxEvals;
	}

	/*
	 * Function evaluation
	 */
	public double getValue(double[] arg) {

		double value = 0.0;
		if (arg.length != numberOfDimensions) {

			return Double.MAX_VALUE;
		} else {

			numberOfFunctionEvaluations++;
			if (numberOfFunctionEvaluations % frequency == 1
					&& numberOfFunctionEvaluations != 1) {

				randomiseAttractor(dynamicRange);
				bestValueSoFar = Double.MAX_VALUE;
			}

			for (int i = 0; i < numberOfDimensions; i++)
				value += Math.pow((arg[i] - attractor[i]), 2.0);

			value += height;

			if (value < bestValueSoFar)
				bestValueSoFar = value;

			application.inform(numberOfFunctionEvaluations, bestValueSoFar);

			return value;
		}
	}

	/*
	 * Attractors is in fact a single attractor for this mono modal function
	 */
	public double[][] getAttractors() {

		double[][] attractors = new double[1][attractor.length];
		attractors[0] = attractor;

		return attractors;
	}

	public void randomiseAttractors(int dynamicRange,
			double minimumAttractorSeparation) {

		randomiseAttractor(dynamicRange);
	}

	public void randomiseAttractor(int dynamicRange) {

		for (int i = 0; i < attractor.length; i++) {
			attractor[i] = (attrRandom.nextDouble() - 0.5) * dynamicRange;
		}
	}

	public void setAttractorValues(double[] h) {

		setAttractorValue(h[0]);
	}

	public void setAttractorValue(double value) {

		height = value;
	}

	public void randomiseAttractorValues() {

		randomiseAttractorValue();
	}

	public void randomiseAttractorValue() {

		height = heightRandom.nextDouble() * maximumHeight;

	}

	public String getStatistics() {

		String message = "";

		message += "Best value so far:\t" + bestValueSoFar + "\n";

		return message;
	}

	public String getParameters() {

		String message = "";

		message += "Single attractor at a = ( " + attractor[0];
		for (int i = 1; i < attractor.length; i++) {
			message += ", " + attractor[i];
		}
		message += " )" + "\n";
		message += "Height = " + height + "\n";
		message += "f( a ) = " + height + "\n";

		return message;
	}

	public int getNumberOfEvals() {

		return numberOfFunctionEvaluations;
	}

	public void print() {

		System.out.print(getParameters());
	}
}
