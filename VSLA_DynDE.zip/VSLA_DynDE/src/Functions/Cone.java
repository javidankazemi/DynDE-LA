package Functions;

//import java.util.*;
import Utilities.MyRandom;

import Utilities.Application;

public class Cone extends ObjectiveFunction {

	double[] attractor;

	double tanTheta;

	int dynamicRange;

	int numberOfDimensions;

	long seed;
	
	MyRandom random;

	double bestValueSoFar = Double.MAX_VALUE;

	int numberOfFunctionEvaluations = 0;

	/*
	 * Place cone on a random point in [-R/2, R/2], where R is dynamic range
	 */
	public Cone(String name, int dims, long seed, int range, double tTheta, Application app) {

		super(name, app);

		numberOfDimensions = dims;
		tanTheta = tTheta;
		dynamicRange = range;
		
		attractor = new double[numberOfDimensions];
		
		this.seed = seed;
		random = new MyRandom(seed);
		
		randomiseAttractor(dynamicRange);
		
		//print();
	}

	/*
	 * Place cone at origin
	 */
	public Cone(String name, int dims, double tTheta, Application app) {

		super(name, app);

		numberOfDimensions = dims;
		tanTheta = tTheta;
			
		attractor = new double[numberOfDimensions];
		
		//print();
	}
	
	/*
	 * Function evaluation
	 */
	public double getValue(double[] arg) {

		double value = Double.MAX_VALUE;

		numberOfFunctionEvaluations++;

		double radius = 0.0;
		for (int i = 0; i < numberOfDimensions; i++)
			radius += Math.pow((arg[i] - attractor[i]), 2.0);
		
		radius = Math.pow(radius, 0.5);

		// find height
		value = tanTheta * radius;
	
		if (value < bestValueSoFar)
			bestValueSoFar = value;

		application.inform(numberOfFunctionEvaluations, bestValueSoFar);
		
		return value;
	}

	/*
	 * Attractors is in fact a single attractor for this mono modal function
	 */
	public double[][] getAttractors() {

		double[][] attractors = new double[1][attractor.length];
		attractors[0] = attractor;

		return attractors;
	}
	
	public void randomiseAttractor(int dynamicRange) {

		for (int i = 0; i < attractor.length; i++) {
			attractor[i] = (random.nextDouble() - 0.5) * dynamicRange;
		}
	}



	public String getStatistics() {

		String message = "";

		message += "Best value so far:\t" + bestValueSoFar + "\n";

		return message;
	}

	public String getParameters() {

		String message = name + " function\n";

		message += "Single attractor at a = ( " + attractor[0];
		for (int i = 1; i < attractor.length; i++) {
			message += ", " + attractor[i];
		}
		message += " )" + "\n";

		return message;
	}

	public int getNumberOfEvals() {

		return numberOfFunctionEvaluations;
	}

	public void print() {

		System.out.print(getParameters());
	}
	
}
