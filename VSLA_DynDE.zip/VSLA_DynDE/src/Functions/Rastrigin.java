package Functions;

import java.util.*;

import Utilities.Application;

public class Rastrigin extends ObjectiveFunction {

	double[] attractor;

	double height;

	int dynamicRange;

	double maximumHeight = 100.0;

	int numberOfDimensions;

	int frequency;

	Random attrRandom = new Random(20052003);

	Random heightRandom = new Random(1565924878);

	double bestValueSoFar = Double.MAX_VALUE;

	int numberOfFunctionEvaluations = 0;

	int maxNumberOfEvals = 500000;

	final double TWOPI = Math.PI * 2.0;

	public Rastrigin(String name, double[] a, int dims, int freq, double h,
			int range, int maxEvals, Application app) {

		super(name, app);

		attractor = a;
		numberOfDimensions = dims;
		frequency = freq;
		height = h;
		dynamicRange = range;
		maxNumberOfEvals = maxEvals;
	}

	/*
	 * Function evaluation
	 */
	public double getValue(double[] arg) {

		if (arg.length != numberOfDimensions) {

			return Double.MAX_VALUE;
		} else {

			numberOfFunctionEvaluations++;
			if (numberOfFunctionEvaluations % frequency == 1
					&& numberOfFunctionEvaluations != 1) {

				randomiseAttractor(dynamicRange);
				bestValueSoFar = Double.MAX_VALUE;
			}

			double[] y = new double[numberOfDimensions];
			for (int i = 0; i < numberOfDimensions; i++) {
				y[i] = arg[i] - attractor[i];
			}

			//  Global minimum is at 0. (f(0) = 0.)
			double temp1 = 0.0;
			double temp2 = 0.0;
			double value = 0.0;
			for (int i = 0; i < numberOfDimensions; i++) {

				temp1 += y[i] * y[i];
				temp2 += -10.0 * Math.cos(TWOPI * y[i]);
			}
			temp2 += 10 * numberOfDimensions;
			value = temp2 + temp1;

			value += height;

			if (value < bestValueSoFar)
				bestValueSoFar = value;

			application.inform(numberOfFunctionEvaluations, bestValueSoFar);

			return value;
		}
	}

	/*
	 * many attractors for this function - this method needs to be filled in -
	 * for the moment just return the global minimiser
	 */
	public double[][] getAttractors() {

		double[][] attractors = new double[1][attractor.length];
		attractors[0] = attractor;

		return attractors;
	}

	public void randomiseAttractors(int dynamicRange,
			double minimumAttractorSeparation) {

		//  NB this is a rescaling of original F2 function by 1000, and a shift
		// of (-1,-1,...)

		randomiseAttractor(dynamicRange);
	}

	public void randomiseAttractor(int dynamicRange) {

		for (int i = 0; i < attractor.length; i++) {
			attractor[i] = (attrRandom.nextDouble() - 0.5) * dynamicRange;
		}
	}

	public void setAttractorValues(double[] h) {

		setAttractorValue(h[0]);
	}

	public void setAttractorValue(double value) {

		height = value;
	}

	public void randomiseAttractorValues() {

		randomiseAttractorValue();
	}

	public void randomiseAttractorValue() {

		height = heightRandom.nextDouble() * maximumHeight;

	}

	public String getStatistics() {

		String message = "";

		message += "Best value so far:\t" + bestValueSoFar + "\n";

		return message;
	}

	public String getParameters() {

		String message = "";

		message += "Single attractor at a = ( " + attractor[0];
		for (int i = 1; i < attractor.length; i++) {
			message += ", " + attractor[i];
		}
		message += " )" + "\n";
		message += "Height = " + height + "\n";
		message += "f( a ) = " + height + "\n";

		return message;
	}

	public int getNumberOfEvals() {

		return numberOfFunctionEvaluations;
	}

	public void print() {

		System.out.print(getParameters());
	}
}
