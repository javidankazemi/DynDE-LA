package Functions;

import java.util.*;

import Utilities.Application;

public class Rosenbrook extends ObjectiveFunction{

    double[] attractor;
    double height;
    int dynamicRange;
    double maximumHeight = 100.0;

    int numberOfDimensions;
    int frequency;

    Random attrRandom = new Random( 20052003);
    Random heightRandom = new Random( 1565924878 );

    double bestValueSoFar = Double.MAX_VALUE;
    int numberOfFunctionEvaluations = 0;
    int maxNumberOfEvals = 500000;

    public Rosenbrook( String name, 
		       double[] a, 
		       int dims, 
		       int freq, 
		       double h, 
		       int range,
		       int maxEvals, 
		       Application app ){

	super( name, app );

	attractor = a;
	numberOfDimensions = dims;
	frequency = freq;
	height = h;
	dynamicRange = range;
	maxNumberOfEvals = maxEvals;
    }


    /*
     *  Function evaluation
     */
    public double getValue( double[] arg ){

	double value = 0.0;
	if ( arg.length != numberOfDimensions || numberOfDimensions == 1 ){

	    return Double.MAX_VALUE;
	}
	else{

	    numberOfFunctionEvaluations++;
	    if ( numberOfFunctionEvaluations % frequency == 1 && numberOfFunctionEvaluations != 1 ){
 
		randomiseAttractor( dynamicRange );
		bestValueSoFar = Double.MAX_VALUE;
	    }
	    
	    double[] y = new double[ numberOfDimensions ];
	    for ( int i = 0; i < numberOfDimensions; i++ ){
		y[ i ] = arg[ i ] - attractor[ i ];
	    }

	    //  NB this is a rescaling of original F2 function by 1000, and a shift of (-1,-1,...)
	    //  so that global minimum is at 0. (f(0) = 0.)
	    for ( int i = 0; i < numberOfDimensions-1; i++ ){
		double dummy = arg[ i + 1 ] - arg[ i ] * arg[ i ];
		value += dummy * dummy + 0.01*( arg[ i ] * arg[ i ] );
	    }

	    value += height;
	    
	    if ( value < bestValueSoFar ) 
		bestValueSoFar = value;

	    application.inform( numberOfFunctionEvaluations, bestValueSoFar );

	    return value;
	}
    }

    /*
     *  Attractors is in fact a single attractor for this mono modal function
     */
    public double[][] getAttractors(){

	double[][] attractors = new double[ 1 ][ attractor.length ];
	attractors[ 0 ] = attractor;

	return attractors;
    }

    public void randomiseAttractors( int dynamicRange, double minimumAttractorSeparation ){
	

	randomiseAttractor( dynamicRange );
    }

    public void randomiseAttractor( int dynamicRange ){

	for ( int i = 0; i < attractor.length; i++ ){
	    attractor[ i ] = ( attrRandom.nextDouble() - 0.5 ) * dynamicRange;
	}
    }

    public void setAttractorValues( double[] h ){

	setAttractorValue( h[ 0 ] );
    }

    public void setAttractorValue( double value ){

	height = value;
    }

    public void randomiseAttractorValues(){

	randomiseAttractorValue();
    }

    public void randomiseAttractorValue(){

	height = heightRandom.nextDouble() * maximumHeight;

    }

    public String getStatistics(){

	String message = "";

	message += "Best value so far:\t" + bestValueSoFar + "\n";

	return message;
    }

    public String getParameters(){

	String message = "";
	
	message += "Single attractor at a = ( " + attractor[ 0 ];
	for ( int i = 1; i < attractor.length; i++ ){
	    message += ", " + attractor[ i ];
	}
	message += " )" + "\n";
	message += "Height = " + height + "\n";
	message += "f( a ) = " + height + "\n";

	return message;
    }

    public int getNumberOfEvals(){

	return numberOfFunctionEvaluations;
    }

    public void print(){
	
	System.out.print( getParameters() );
    }
}
	

