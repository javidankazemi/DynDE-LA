package Functions;

import Functions.Peaks.*;
import Utilities.*;

public class PeakFunction extends ObjectiveFunction {

	private movpeaks peaks;

	private int dynamicRange;

	private int numberOfAttractors;

	private int numberOfDimensions;

	private double peaksMinCoordinate;

	private double peaksDynamicRange;

	private double msoMinCoordinate;

	private double ratioOfDynamicRanges;

	private int numberOfFunctionEvaluations = 0;

	private int maxNumberOfEvals = 500000;

	public PeakFunction(String name, int numberOfAttractors,
			int numberOfDimensions, int changeFrequency, double vlength,
			long seed, int dynamicRange, int maxNumberOfEvals, Application app) {

		super(name, app);

		this.dynamicRange = dynamicRange;
		this.numberOfAttractors = numberOfAttractors;
		this.numberOfDimensions = numberOfDimensions;

		this.maxNumberOfEvals = maxNumberOfEvals;

		peaks = new movpeaks(numberOfAttractors, numberOfDimensions,
				changeFrequency, vlength, seed);

		System.gc();

		peaks.init_peaks();

		peaksMinCoordinate = peaks.getMinCoordinate();
		peaksDynamicRange = peaks.getMaxCoordinate() - peaksMinCoordinate;
		msoMinCoordinate = -1.0 * (double) (dynamicRange) / 2.0;
		ratioOfDynamicRanges = peaksDynamicRange / dynamicRange;

	}

	/*
	 * Function evaluation
	 */
	public double getValue(double[] arg) {

		/*
		 * in movpeaks, coordinate range is [0, dynamicRange ] in MSO,
		 * coordinate range is [ -dynamicRange/2, dynamicRange/2 ]
		 */
		double[] gen = new double[numberOfDimensions];
		for (int i = 0; i < arg.length; i++) {

			gen[i] = peaksMinCoordinate + (arg[i] - msoMinCoordinate)
					* ratioOfDynamicRanges;
		}

		numberOfFunctionEvaluations++;

		double result = peaks.getMaxHeight() - peaks.eval_movpeaks(gen);

		application.inform(numberOfFunctionEvaluations, peaks
				.get_offline_error());

		return result;
	}

	/*
	 *  
	 */
	public double[][] getAttractors() {

		double[][] peakPositions = peaks.getPeakPositions();
		double[][] attractors = new double[numberOfAttractors][numberOfDimensions];

		for (int i = 0; i < numberOfAttractors; i++) {
			for (int j = 0; j < numberOfDimensions; j++) {
				attractors[i][j] = msoMinCoordinate
						+ (peakPositions[i][j] - peaksMinCoordinate)
						/ ratioOfDynamicRanges;
			}
		}
		return attractors;
	}

	public void randomiseAttractors(int dynamicRange,
			double minimumAttractorSeparation) {

		peaks.change_peaks();
	}

	public void setAttractorValues(double[] h) {

	}

	public void randomiseAttractorValues() {

	}

	public double getMaxHeight() {

		return peaks.getMaxHeight();
	}

	public int getMaximumPeak() {

		return peaks.getMaximumPeak();
	}

	public double getGlobalmax() {

		return peaks.getGlobalMax();
	}

	public int getNumberOfEvals() {

		return peaks.get_number_of_evals();
	}

	public void print() {

	}

	public String getStatistics() {

		String message = "";

		message += "Evals:\t" + peaks.get_number_of_evals() + "\n";
		message += "Average error:\t" + peaks.get_avg_error() + "\n";
		message += "Current error:\t" + peaks.get_current_error() + "\n";
		message += "Offline perf:\t" + peaks.get_offline_performance() + "\n";

		message += "Offline error:\t" + peaks.get_offline_error() + "\n";

		message += "Current peak:\t" + peaks.getCurrentPeak() + "\n";
		message += "Maximum peak:\t" + peaks.getMaximumPeak() + "\n";
		message += "Maxpeak val:\t" + peaks.getGlobalMax() + "\n";

		return message;
	}

	public String getParameters() {

		return peaks.getParameters();
	}

}
