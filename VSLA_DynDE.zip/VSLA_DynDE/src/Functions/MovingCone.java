package Functions;

//import java.util.*;
import Utilities.MyRandom;

import Utilities.Application;

public class MovingCone extends ObjectiveFunction {

	double[] attractor;

	double[] movement;

	double tanTheta;

	double vlength;
	
	// Set to zero for uncorrelated, set to 1.0 for correlated
	double lambda; 

	int changeFrequency;

	int dynamicRange;

	int numberOfDimensions;

	long seed;

	MyRandom random;

	double bestValueSoFar = Double.MAX_VALUE;

	int numberOfFunctionEvaluations = 0;

	/*
	 * Place cone on a random point in [-R/2, R/2], where R is dynamic range
	 */
	public MovingCone(String name, int dims, long seed, int range,
			double tTheta, double vl, int cf, double lm,  Application app) {

		super(name, app);

		numberOfDimensions = dims;
		tanTheta = tTheta;

		vlength = vl;
		changeFrequency = cf;
		lambda = lm;

		dynamicRange = range;

		attractor = new double[numberOfDimensions];
		movement = new double[numberOfDimensions];

		this.seed = seed;
		random = new MyRandom(seed);

		randomiseAttractor(dynamicRange);
		randomiseVelocity();

		//print();
	}

	/*
	 * Function evaluation
	 */
	public double getValue(double[] arg) {

		double value = Double.MAX_VALUE;

		double radius = 0.0;
		for (int i = 0; i < numberOfDimensions; i++)
			radius += Math.pow((arg[i] - attractor[i]), 2.0);

		radius = Math.pow(radius, 0.5);

		// find height
		value = tanTheta * radius;

		if (value < bestValueSoFar)
			bestValueSoFar = value;

		numberOfFunctionEvaluations++;

		application.inform(numberOfFunctionEvaluations, value);

		// move cone
		if (numberOfFunctionEvaluations % changeFrequency == 0) {
			if (lambda == 0.0)
				randomiseVelocity();
			for (int i = 0; i < numberOfDimensions; i++)
				attractor[i] += movement[i];
		}

		return value;
	}

	/*
	 * Attractors is in fact a single attractor for this mono modal function
	 */
	public double[][] getAttractors() {

		double[][] attractors = new double[1][attractor.length];
		attractors[0] = attractor;

		return attractors;
	}

	public void randomiseAttractor(int dynamicRange) {

		for (int i = 0; i < attractor.length; i++) {
			attractor[i] = (random.nextDouble() - 0.5) * dynamicRange;
		}
	}

	public void randomiseVelocity() {

		double magnitude = 0.0;
		for (int i = 0; i < numberOfDimensions; i++) {

			movement[i] = 2.0 * (random.nextDouble() - 0.5);
			magnitude += (movement[i] * movement[i]);
		}

		magnitude = Math.pow(magnitude, 0.5);
		double factor = vlength / magnitude;

		for (int i = 0; i < numberOfDimensions; i++) {

			movement[i] *= factor;
		}

	}

	public String getStatistics() {

		String message = "";

		message += "Best value so far:\t" + bestValueSoFar + "\n";

		return message;
	}

	public String getParameters() {

		String message = name + " function\n";

		message += "Single attractor at a = ( " + attractor[0];
		for (int i = 1; i < attractor.length; i++) {
			message += ", " + attractor[i];
		}
		message += " )" + "\n";

		return message;
	}

	public int getNumberOfEvals() {

		return numberOfFunctionEvaluations;
	}

	public double[] getMovement() {

		return movement;
	}

	public double getVlength() {

		return vlength;
	}

	public void print() {

		System.out.print(getParameters());
	}

}
