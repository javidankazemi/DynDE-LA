package MultiSwarm;

import java.util.ArrayList;
import java.util.Collections;

public class MultiSwarm {

    private ArrayList swarms;

    public MultiSwarm() {

        swarms = new ArrayList();
    }

    public synchronized void addSwarm(Swarm s) {

        swarms.add(s);
    }

    public synchronized void addSwarm(int i, Swarm s) {

        swarms.add(i, s);
    }

    public synchronized Swarm getSwarm(int i) {

        Swarm s = null;

        if (!swarms.isEmpty()) {

            try {

                s = (Swarm) swarms.get(i);
            } catch (IndexOutOfBoundsException e) {

                //  Do nothing
            }
        }

        return s;
    }

    public synchronized void removeSwarm(int i) {

        Swarm s = null;

        if (!swarms.isEmpty()) {

            try {
                s = (Swarm) swarms.remove(i);
            } catch (IndexOutOfBoundsException e) {

                //  Do nothing
            }
        }
    }

    public synchronized int size() {

        return swarms.size();
    }
    
    /*
     * Find worst swarm, where worst means largest function value at swarm
     * attractor. NB if only one swarm, it will be the worst (as well as he
     * best!)
     */
    public int getWorstSwarm() {

        int worst = 0;
        Swarm swarm = getSwarm(0);
        double worstValue = swarm.getParticle(swarm.getIndex()).getValue();

        for (int n = 1; n < size(); n++) {

            swarm = getSwarm(n);
            double fng = swarm.getParticle(swarm.getIndex()).getValue();
            if (fng > worstValue) {
                worst = n;
                worstValue = fng;
            }
        }
        return worst;
    }

    public int getWorstFreeSwarm() {

        int worst = -1;
        double worstValue = Double.MIN_VALUE;

        //find the worst free swarm
        for (int n = 0; n < size(); n++) {

            Swarm swarm = getSwarm(n);
            if (!swarm.getConverged()) {

                double fng = swarm.getParticle(swarm.getIndex()).getValue();

                if (fng > worstValue) {
                    worst = n;
                    worstValue = fng;
                }
            }
        }
        return worst;
    }

    /*
     * Find best swarm, where best means smallest function value at swarm
     * attractor. NB if only one swarm, it will be the best (as well as he
     * worst!)
     */
    public int getBestSwarm() {

        int best = 0;
        Swarm swarm = getSwarm(0);
        double bestValue = swarm.getParticle(swarm.getIndex()).getValue();

        for (int n = 1; n < size(); n++) {

            swarm = getSwarm(n);
            double fng = swarm.getParticle(swarm.getIndex()).getValue();
            if (fng < bestValue) {
                best = n;
                bestValue = fng;
            }
        }
        return best;
    }

    public boolean isWorstSwarm(int n) {

        if (n == getWorstSwarm())
            return true;
        else
            return false;
    }
    
    public void sortSwarms(){
        Collections.sort(swarms);
    }
}
