package MultiSwarm;

import Functions.ObjectiveFunction;
import Utilities.MyRandom;

import LearningAutomata.VariableStructureLA;

public class MSO {

    /*
     * This is a multi-population differential evolution with learning automata based function evaluation management (DynDE+LA).
     * Searches for function minimizer.
     */

    /*
     * DynDE parameters
     *
     */ 
    
    protected double F; // spring constant for Mutation rate in Differential Mutation
    protected boolean randomF;
    protected double CR; // spring constant for CrossOver rate should be in [0, 1]
    protected boolean randomCR;
    /*
     * Random objects
     */
    private MyRandom random;

    /*
     * Coulomb parameters
     */
    protected double perceptionLimit;

    protected double particleCharge;
    
    protected double sigma;

    /*
     * Algorithm parameters
     */
    protected boolean checkForChange = true;

    /*
     * Dynamic parameters
     */
    protected double dynamicRange = 10;

    protected int numberOfDimensions = 2;

    protected double exclusionRadius = 1.0;

    protected double convergenceRadius = 1.0;

    /*
     * Function
     */
    protected ObjectiveFunction objectiveFunction;

    /*
     * Multi-population parameters
     */
    protected MultiSwarm multiSwarm;

    protected int numNeutralParticlesInSwarm;

    protected int numChargedParticlesInSwarm;

    protected int numParticlesInSwarm;

    protected boolean selfAdapt;

    /*
     * Counters
     */
    protected int numberOfIterations = 0;

    /*
     * Constants
     */
    final double PI = Math.PI;

    final double TWOPI = 2.0 * PI;

    final double HALFPI = PI / 2.0;

    final double SMALLVALUE = 1.0e-50;
    
    private VariableStructureLA LA;
    
    protected double alpha = 1.0;

    /*
     * Constructors
     */
    public MSO() {

    }

    public MSO(int numberOfSwarms, int numParticles, int numNeutral,
            int numCharged, double charge, int numDims, double dyRan,
            long seed, boolean sa, boolean de) {

        /*
         * Set spatial paramters
         */
        numberOfDimensions = numDims;
        dynamicRange = dyRan;

        /*
         * Set population parameters
         */
        numParticlesInSwarm = numParticles;
        numNeutralParticlesInSwarm = numNeutral;
        numChargedParticlesInSwarm = numCharged;
        particleCharge = charge;

        /*
         * Set algorithm paramters
         */
        selfAdapt = sa;
        checkForChange = de;

        /*
         * PRNG
         */
        random = new MyRandom(seed);

        multiSwarm = new MultiSwarm();

        for (int n = 0; n < numberOfSwarms; n++) {

            Swarm swarm = Swarm.makeRandomisedSwarm(numberOfDimensions,
                    dynamicRange, numParticlesInSwarm,
                    numChargedParticlesInSwarm, particleCharge, random);
            multiSwarm.addSwarm(swarm);
        }
        // reward parameter a = 0.2, and penalty parameter b = 0.05
        double a = 0.15, b = 0.05;
        //initialize LAsub-pop with corresponding a and b
        LA = new VariableStructureLA(numberOfSwarms, a, b, random.nextInt());
        
    }

    /*
     * update fixed point k of swarm n there is a single f-eval at position x:
     * 
     * if f = f(x) < fnk then fnk = f and pnk = xnk if fnk < fng then g = k
     */
    private void updateFixedPoint(int k, int n) {

        Swarm swarm = multiSwarm.getSwarm(n);
        Particle particle = swarm.getParticle(k);

        double[] p = particle.getPosition();
        double[] x = particle.getOffspring(); // new generated individual for this individual

        double fx = objectiveFunction.getValue(x);
        double fp = particle.getValue();

        /*
         * Update individual fixed point
         */
        if (fx <= fp) { // it is necessary for flat landscapes in order to explore

            System.arraycopy(x, 0, p, 0, numberOfDimensions);
            particle.setValue(fx);
            fp = fx;
        }
        
        

        double charge = particle.getCharge();
        if(charge != 0.0) // quantom or Brownian individual
        {
            particle.setValue(fx);
            fp = fx;
        }


        /*
         * Now update swarm fixed point
         */
        int indexOfBest = swarm.getIndex();
        double fpg = swarm.getParticle(indexOfBest).getValue();

        if (fp < fpg) {

            swarm.setIndex(k);
        }
    }

    /*
     * updates the index gn of the best individual in populations n i.e. ensures that
     * fng = min{fnk} gn = 0 for all individuals k > 0 if fnk < fng then g = n
     */
    private void updateIndex(int n) {

        Swarm swarm = multiSwarm.getSwarm(n);

        swarm.setIndex(0);

        for (int k = 1; k < swarm.size(); k++) {

            double fnk = swarm.getParticle(k).getValue();

            int g = swarm.getIndex();
            double fng = swarm.getParticle(g).getValue();

            if (fnk < fng) {

                swarm.setIndex(k);
            }
        }
    }

    /*
     * update all fnk = f(pnk) and ensure that fgk = min{fnk}
     */
    private void updateAllFixedPoints(int n) {

        Swarm swarm = multiSwarm.getSwarm(n);

        /*
         * update all stored function values fnk
         */
        for (int k = 0; k < swarm.size(); k++) {

            // fnk = f(pnk)
            Particle particle = swarm.getParticle(k);
            double fnk = objectiveFunction.getValue(particle.getPosition());
            particle.setValue(fnk);
        }

        /*
         * Since f changes at f-evals, need to set g (swarm.index) after
         * updating all the fnk's
         */
        updateIndex(n);
    }

    /*
     * Exclusion
     * 
     * This version examines non-excluded populations in pairs, and marks the loser
     * for randomisation in the next iteration.
     */
    private void exclusion() {

        double exclRadius = exclusionRadius;
        if (selfAdapt)
            exclRadius = getDynamicRadius();

        int numSwms = multiSwarm.size();

        // Initialise excluded variables
        for (int n = 0; n < numSwms; n++) {

            Swarm swarm = multiSwarm.getSwarm(n);
            swarm.setExcluded(false);
        }

        // Examine swarms in pairs.
        // If neither has yet been excluded, apply exclusion
        loopN: for (int n = 0; n < multiSwarm.size(); n++) {

            Swarm swarmN = multiSwarm.getSwarm(n);

            // Move to next n if already excluded
            if (swarmN.getExcluded())
                continue loopN;

            loopM: for (int m = n + 1; m < multiSwarm.size(); m++) {

                Swarm swarmM = multiSwarm.getSwarm(m);

                // Move to next m if already excluded
                if (swarmM.getExcluded())
                    continue loopM;

                int gM = swarmM.getIndex();
                int gN = swarmN.getIndex();

                double sep = getEuclideanDistance(swarmM.getParticle(gM)
                        .getPosition(), swarmN.getParticle(gN)
                        .getPosition());

                // Now check for possible exclusion
                if (sep < exclRadius) {

                    double fng = swarmN.getParticle(gN).getValue();
                    double fmg = swarmM.getParticle(gM).getValue();

                    // Exclude the loser in a simple competition
                    if (fng < fmg)
                        swarmM.setExcluded(true);

                    else if (fmg < fng) {

                        swarmN.setExcluded(true);

                        // population n has been excluded so break this loop and
                        // start again with swarm n+1
                        break loopM;
                    } else {
                        // DO NOTHING IN THE UNLIKELY EVENT OF A TIE???
                    }
                }
            } // end individual m loop
        } // end individual n loop
    }
    

    private void testForConvergence(int n) {

        double convRadius = convergenceRadius;

        if (selfAdapt)
            convRadius = getDynamicRadius();

        Swarm swarm = multiSwarm.getSwarm(n);

        if (swarmSize(n, 0.0) < 2.0 * convRadius) 
            swarm.setConverged(true);

        else 
            swarm.setConverged(false);
    }

    public double getDynamicRadius() {

        int numberOfSwarms = multiSwarm.size();
        return dynamicRange
                / (2.0 * Math.pow(numberOfSwarms, 1.0 / numberOfDimensions));
    }

    public int getNumberOfConvergedSwarms() {

        int numberOfConvergedSwarms = 0;
        int numberOfSwarms = multiSwarm.size();
        for (int n = 0; n < numberOfSwarms; n++) {

            Swarm swarm = multiSwarm.getSwarm(n);

            if (swarm.getConverged())
                numberOfConvergedSwarms++;

        }
        return numberOfConvergedSwarms;
    }

    public int getNumberOfFreeSwarms() {

        return (multiSwarm.size() - getNumberOfConvergedSwarms());
    }

    /*
     * Anti-Convergence NB A single population will always be the worst (and the
     * best!) population so it will always be re-initialised if size <
     * convergenceRadius. The Anti-Convergence has not been used in the SWEVO paper.
     * 
     * This version of anti-convergence will mark a converged population for
     * randomisation at the next iteration.
     */
    public void antiConvergence() {

        int numberOfConvergedSwarms = getNumberOfConvergedSwarms();
        int numberOfSwarms = multiSwarm.size();

        if (numberOfConvergedSwarms == numberOfSwarms) {

            int worst = multiSwarm.getWorstSwarm();
            Swarm swarm = multiSwarm.getSwarm(worst);
            swarm.setExcluded(true);
        }
    }

    /*
     * Method to adapt number of population. self-adaptation has not been used in the SWEVO
     */
    public void adaptMultiSwarm() {

        int numberOfConvergedSwarms = getNumberOfConvergedSwarms();
        int numberOfSwarms = multiSwarm.size();
        int numberOfFreeSwarms = numberOfSwarms - numberOfConvergedSwarms;

        // Choose desired number of free populations.
        int n_excess = 3;

        if (numberOfConvergedSwarms == numberOfSwarms) {

            // Add populatio
            Swarm swarm = Swarm.makeRandomisedSwarm(numberOfDimensions,
                    dynamicRange, numParticlesInSwarm,
                    numChargedParticlesInSwarm, particleCharge, random);
            multiSwarm.addSwarm(swarm);

            // Print to terminal

        }

        else if (numberOfFreeSwarms > n_excess) {

            // Remove population
            multiSwarm.removeSwarm(multiSwarm.getWorstFreeSwarm());

        }

    }

    private boolean detectAndUpdateFixedPoints(int n) {

        boolean change = false;

        Swarm swarm = multiSwarm.getSwarm(n);
        int g = swarm.getIndex();
        double[] png = swarm.getParticle(g).getPosition();
        double fpng = objectiveFunction.getValue(png);
        double fng = swarm.getParticle(g).getValue();
        if (fng != fpng) {

            change = true;

            for (int k = 0; k < swarm.size(); k++) {

                Particle particle = swarm.getParticle(k);
                if (k != g) {
                    double fnk = objectiveFunction.getValue(particle
                            .getPosition());
                    particle.setValue(fnk);
                } else {
                    particle.setValue(fpng);
                }
            }
            updateIndex(n);
        }
        return change;
    }

    /*
     * Multi-population update
     */
    public void updateMultiSwarm() {
        

        boolean change = false;
        
        if (selfAdapt) {
            adaptMultiSwarm();
        }

        else if (convergenceRadius > 0.0) {
            // Anti-Convergence: exclude the worst population
            antiConvergence();
        }

        for (int n = 0; n < multiSwarm.size(); n++) {

            Swarm swarm = multiSwarm.getSwarm(n);

            // Detect change and respond
            change = false;
            if (checkForChange)
                change = detectAndUpdateFixedPoints(n);

            // If environment has changed, cancel, if necessary, an exclusion
            if (change) {
                swarm.setExcluded(false);
            }

            if (swarm.getExcluded()) {
                // If population is excluded, randomise
                swarm.randomiseSwarm(random);
                updateAllFixedPoints(n);
            } else {
                // Not excluded - allow population update



                //LAsub-pop chooses on of its actions, i.e. population to be executed
                int selectedSwarm = LA.select_action();

                int bestSwarm = multiSwarm.getBestSwarm();
                
                double fBestBeforeUpdate = 0.0, fBestAfterUpdate = 0.0;
                double beta = 0.0;
                
                
                
                
                if(selectedSwarm == n){
                    fBestBeforeUpdate = multiSwarm.getSwarm(bestSwarm).getBestParticle().getValue();
                    moveAllParticles(n);
                    fBestAfterUpdate = multiSwarm.getSwarm(bestSwarm).getBestParticle().getValue();

                    //calculating the feedback by checking if the quality of the best-found solution has been improved
                    if (fBestAfterUpdate != fBestBeforeUpdate) {
                        beta = 0.0;//positive feedback
                    } else {
                        beta = 1.0;//negative feedback
                    }
                    
                }else{
                    //move Brownian individuals
                    moveBrownianParticles(n);
                    
                    
                    fBestBeforeUpdate = multiSwarm.getSwarm(bestSwarm).getBestParticle().getValue();
                    moveAllParticles(selectedSwarm);
                    fBestAfterUpdate = multiSwarm.getSwarm(bestSwarm).getBestParticle().getValue();
                    
                    if (fBestAfterUpdate != fBestBeforeUpdate) {
                        beta = 0.0;
                    } else {
                        beta = 1.0;
                    }                    
                    
                }

                //update the probability vector of the LAsub-pop using the feedback recieved from the environment
                LA.update(beta);

            }
            // Set population.converged to true if population has converged and vice versa
            if (selfAdapt || (convergenceRadius > 0.0))
                testForConvergence(n);
        }

        // If neither population has been excluded, exclude worse population
        if (selfAdapt || (exclusionRadius > 0.0))
            exclusion();

        if(change && numberOfIterations !=0)
            LA.resetLA();// if a change is detected reset the probability vector of LAsub-pop
        ++numberOfIterations;

    }

private void moveAllParticles(int n){
        Swarm swarm = multiSwarm.getSwarm(n);
        
         for (int k = 0; k < swarm.size(); k++) {


            updateParticle(k, n);
            updateFixedPoint(k, n);

        }
    }
 
    //move Brownian individuals
    private void moveBrownianParticles(int n){
        Swarm swarm = multiSwarm.getSwarm(n);
        
        int nBrownian = numChargedParticlesInSwarm;
        int s = 0;
         for (int k = 0; k < swarm.size(); k++) {

             double ch = swarm.getParticle(k).getCharge();
             if(ch!=0.0){
                updateParticle(k, n);
                updateFixedPoint(k, n);
             }

        }
            
    }    
    /*
     * Individual update
     */
    public void updateParticle(int k, int n) {

        Swarm swarm = multiSwarm.getSwarm(n);
        Particle particle = swarm.getParticle(k);

        double charge = particle.getCharge();

        if (charge == 0.0)
            updateClassicalParticle(k, n);

        else
            //updateQuantumParticle(k, n);
            updateBrownianParticle(k, n);

    }
    
    
    public void updateBrownianParticle(int k, int n) {

        Swarm swarm = multiSwarm.getSwarm(n);
        Particle particle = swarm.getParticle(k);

        double[] x = particle.getPosition();
        double[] pg = swarm.getParticle(swarm.getIndex()).getPosition();
        
        double[] offspring = particle.getOffspring();

        for (int j = 0; j < numberOfDimensions; j++) {
            
            x[j] = pg[j] + (random.nextGaussian()*sigma);
            

            offspring[j] = x[j];
        }


    }
    

    public void updateQuantumParticle(int k, int n) {

        Swarm swarm = multiSwarm.getSwarm(n);
        Particle particle = swarm.getParticle(k);

        double[] x = particle.getPosition();
        double[] pg = swarm.getParticle(swarm.getIndex()).getPosition();
        
        double[] offspring = particle.getOffspring();

        double[] posInCloud = new double[numberOfDimensions];
        posInCloud = getPositionInCloud();

        for (int j = 0; j < numberOfDimensions; j++) {

            x[j] = pg[j] + posInCloud[j];
            offspring[j] = x[j];
        }

    }

    //Update DE individuals according to DE/best/2/bin mutation strategy
    public void updateClassicalParticle(int k, int n) {


        Swarm swarm = multiSwarm.getSwarm(n);
        
        int swarmSize = swarm.size();
        
        int r1, r2, r3, r4;
        
        r1 = random.nextInt(swarmSize);
        while(r1 == k)
            r1 = random.nextInt(swarmSize);

        r2 = random.nextInt(swarmSize);
        while(r2 == k || r2==r1)
            r2 = random.nextInt(swarmSize);

        r3 = random.nextInt(swarmSize);
        while(r3==k || r3==r1 || r3==r2)
            r3 = random.nextInt(swarmSize);
        
        r4 = random.nextInt(swarmSize);
        while(r4==k || r4==r1 || r4==r2 || r4==r3)
            r4 = random.nextInt(swarmSize);
        

        
        int j = random.nextInt(numberOfDimensions); // it is necessary for crossover
        
        Particle particle = swarm.getParticle(k);
        
        

        double[] offspring = particle.getOffspring();
        
        if(randomCR)
        {
            CR = random.nextDouble();
        }
        
        for (int d = 0; d < numberOfDimensions; d++) {

            if(j==d || random.nextDouble()<CR)
            {
                if(randomF)
                {
                    F = random.nextDouble();
                }
                offspring[d] = swarm.getBestParticle().getPositionComponent(d) +
                        F*(swarm.getParticle(r1).getPositionComponent(d) + swarm.getParticle(r2).getPositionComponent(d)
                         - swarm.getParticle(r3).getPositionComponent(d) - swarm.getParticle(r4).getPositionComponent(d));

                
                if(offspring[d] > (dynamicRange/2.0))
                    offspring[d] = dynamicRange/2.0;
                else if(offspring[d] < -(dynamicRange/2.0))
                    offspring[d] = -dynamicRange/2.0;
            }
            else
            {
                offspring[d] = swarm.getParticle(k).getPositionComponent(d);
            }
        }

        
    }

    /*
     * Method to find position in cloud
     */
    private double[] getPositionInCloud() {

        /*
         * Choose uniform distribution in hypersphere
         */
        return getPointInHypersphere(perceptionLimit);
    }

    /*
     * Uniform distribution within hypersphere
     */
    private double[] getPointInHypersphere(double radius) {

        /*
         * Get point inside hypersphere by multiplying by U**(1/d). See Knuth
         * 3.4.1
         */
        double[] x = getPointOnHypersphere(radius);
        double u = random.nextDouble();
        double r = Math.pow(u, 1.0 / numberOfDimensions);

        for (int i = 0; i < x.length; i++)
            x[i] *= r;

        return x;
    }

    /*
     * Helper method for uniform distribution in hypersphere. This finds a point
     * on the surface of hypersphere with given radius
     */
    private double[] getPointOnHypersphere(double radius) {

        double[] x = new double[numberOfDimensions];

        /*
         * Knuth Vol II section 3.4.1 algorithm for generating points on a unit
         * hypersphere is to generate d gaussian random variables from N(0, 1)
         * and then normalise
         */
        for (int j = 0; j < numberOfDimensions; j++) {

            x[j] = random.nextGaussian();
        }

        double[] origin = new double[numberOfDimensions];
        double length = getEuclideanDistance(origin, x);

        if (length < SMALLVALUE)
            length = SMALLVALUE;

        double scale = radius / length;
        for (int j = 0; j < numberOfDimensions; j++) {
            x[j] *= scale;

        }

        return x;
    }

    /*
     * Method to calculate population size by averaging size along each dimension.
     * Size is defined as maxj - minj where maxj = max{ x0j, x1j,...xNj } minj =
     * min{ x0j, x1j,...xNj} and x0j is j'th component of position of individual
     * 0. Only individuals of the specified charge are included in the
     * computation. If no individuals of this charge exist, the returned size is
     * negative.
     */
    public double swarmSize(int n, double charge) {

        double size = swarmSizeComponent(n, 0, charge);

        for (int j = 1; j < numberOfDimensions; j++) {

            double nextSize = swarmSizeComponent(n, j, charge);
            if (nextSize > size)
                size = nextSize;
        }
        return size;
    }

    public double swarmSizeComponent(int n, int j, double charge) {

        double min = Double.MAX_VALUE;
        double max = Double.MIN_VALUE;

        Swarm swarm = multiSwarm.getSwarm(n);
        double[] pg = swarm.getParticle(swarm.getIndex()).getPosition();

        for (int i = 0; i < swarm.size(); i++) {

            if (swarm.getParticle(i).getCharge() == charge) {

                double x = swarm.getParticle(i).getPositionComponent(j);
                double delta = x - pg[j];

                if (delta > max)
                    max = delta;
                if (delta < min)
                    min = delta;
            }
        }
        return max - min;
    }

    /*
     * Method to calculate Euclidean distance between two vectors
     */
    public double getEuclideanDistance(double[] a, double[] b) {

        double distance = 0.0;

        for (int j = 0; j < numberOfDimensions; j++) {

            double diffOfComponents = a[j] - b[j];
            distance += Math.pow(diffOfComponents, 2.0);
        }

        return Math.sqrt(distance);
    }

    /*
     * Multi population parameters
     */
    public int getNumberOfSwarms() {

        return multiSwarm.size();
    }

    public int getNumberOfParticlesInSwarm(int n) {

        return multiSwarm.getSwarm(n).size();
    }

    public Swarm getSwarm(int n) {

        return multiSwarm.getSwarm(n);
    }

    public double getPositionComponent(int n, int k, int j) {

        return multiSwarm.getSwarm(n).getParticle(k).getPositionComponent(j);
    }

    public double getFixedPointComponent(int n, int k, int j) {

        return multiSwarm.getSwarm(n).getParticle(k).getPositionComponent(j);
    }

    public double getSwarmFixedPointComponent(int n, int j) {

        // return multiSwarm.getSwarm( n ).getSwarmFixedPointComponent( j );
        Swarm swarm = multiSwarm.getSwarm(n);
        int g = swarm.getIndex();
        return swarm.getParticle(g).getPositionComponent(j);
    }

    /*
     * Dynamic parameters
     */
    public void setDynamicRange(double d) {

        if (d > 0) {
            dynamicRange = d;
        }
    }

    public double getDynamicRange() {

        return dynamicRange;
    }

    public void setNumberOfDimensions(int i) {

        numberOfDimensions = i;
    }

    public int getNumberOfDimensions() {

        return numberOfDimensions;
    }

    public void setExclusionRadius(double d) {

        exclusionRadius = d;
    }

    public double getExclusionRadius() {

        return exclusionRadius;
    }

    public void setConvergenceRadius(double d) {

        convergenceRadius = d;
    }

    public double getConvergenceRadius() {

        return convergenceRadius;
    }

    /*
     * Attractors and Function
     */

    public void setObjectiveFunction(ObjectiveFunction oF) {

        objectiveFunction = oF;
    }

    public ObjectiveFunction getObjectiveFunction() {

        return objectiveFunction;
    }

    /*
     * DE Parameters
     */
    public void setF(double d) {

        F = d;
    }
    
    public void setRandomF(boolean v)
    {
        randomF = v;
    }

    public void setCR(double d) {

        CR = d;
    }
    
    public void setRandomCR(boolean v)
    {
        randomCR = v;
    }
    /*
     * Perception Parameters
     */
    public void setPerceptionLimit(double d) {

        perceptionLimit = d;
    }
    
    public void setPerceptionSigma(double d) {

        sigma = d;
    }
    public double getCharge(int n, int k) {

        Swarm swarm = multiSwarm.getSwarm(n);
        Particle particle = swarm.getParticle(k);
        return particle.getCharge();
    }

    public void setCharge(int n, int k, double charge) {

        Swarm swarm = multiSwarm.getSwarm(n);
        Particle particle = swarm.getParticle(k);
        particle.setCharge(charge);
    }
    
    

    public void setParticleCharge(double q) {

        particleCharge = q;
    }
    
   
    /*
     * Algorithm Parameters
     */
    public void checkForChange(boolean b) {

        checkForChange = b;
    }

    /*
     * Statistics
     */
    public double getBestValue(int n) {

        Swarm swarm = multiSwarm.getSwarm(n);
        int g = swarm.getIndex();
        return swarm.getParticle(g).getValue();
    }

    public double getBestValue() {

        int n = 0;
        double bestValue = Double.MAX_VALUE;
        double currentValue = bestValue;
        do {
            if ((currentValue = getBestValue(n)) < bestValue)
                bestValue = currentValue;
        } while (++n < multiSwarm.size());

        return bestValue;
    }

    public int getBestSwarm() {

        return multiSwarm.getBestSwarm();
    }

    public int getNumberOfIterations() {

        return numberOfIterations;
    }

    /*
     * Print fnk's
     */
    public void printFunctionValues(int n) {

        Swarm swarm = multiSwarm.getSwarm(n);
        for (int k = 0; k < swarm.size(); k++) {
            System.out.println("f(p " + n + " " + k + ") = "
                    + swarm.getParticle(k).getValue());
        }
        int g = swarm.getIndex();
        System.out.println("f(p " + n + " " + g + " ) = "
                + swarm.getParticle(g).getValue());
    }

    /*
     * Print methods
     */
    public void printSwarm(int n) {

        System.out.println();

        Swarm swarm = multiSwarm.getSwarm(n);
        int numberOfParticles = swarm.size();

        for (int i = 0; i < numberOfParticles; i++) {

            Particle particle = swarm.getParticle(i);
            double[] x = particle.getPosition();

            int numberOfDimensions = x.length;

            System.out.print("x = (");
            for (int j = 0; j < numberOfDimensions - 1; j++) {
                System.out.print(x[j] + ", ");
            }
            System.out.println(x[numberOfDimensions - 1] + ")");

            System.out.println();
        }

        System.out.println();

        for (int i = 0; i < numberOfParticles; i++) {
            System.out.print("Q = (");
            System.out.println(swarm.getParticle(i).getCharge() + ")");

        }

        System.out.println();
    }

    public String getParameterString() {

        String s = "Num populations: " + multiSwarm.size() + "\n";
        for (int n = 0; n < multiSwarm.size(); n++) {
            int swarmSize = multiSwarm.getSwarm(n).size();
            s += "Number of individuals in population " + n + ": " + swarmSize + "\n";
        }
        s += "Num dimensions: "
                + multiSwarm.getSwarm(0).getParticle(0).getPosition().length
                + "\n";
        s += "Dynamic range: " + dynamicRange + "\n";
        s += ("Function: " + objectiveFunction.getName() + "\n");
        
        if(randomF)
            s += "F: " + "Random"+ "\n";
        else
            s += "F: " + F + "\n";
        
        if(randomCR)
            s += "CR: " + "Random" + "\n";
        else
            s += "CR: " + CR + "\n";
        s += "Perception limit: " + perceptionLimit + "\n";
        s += "Exclusion radius: " + exclusionRadius + "\n";
        s += "Convergence radius: " + convergenceRadius + "\n";

        if (exclusionRadius == 0.0)
            s += "EXCLUSION IS OFF" + "\n";
        if (convergenceRadius == 0.0)
            s += "ANTI-CONVERGENCE IS OFF" + "\n";

        double charge = 0.0;
        int numElectrons = 0;
        for (int n = 0; n < multiSwarm.size(); n++) {

            Swarm swarm = multiSwarm.getSwarm(n);
            numElectrons = 0;

            for (int k = 0; k < swarm.size(); k++) {

                double currentCharge = swarm.getParticle(k).getCharge();

                if (currentCharge != 0.0) {
                    numElectrons++;
                    charge = currentCharge;
                }
            }
            s += "Number of individuals in population " + n + ": " + numElectrons
                    + "\n";
        }
        if (numElectrons > 0)
            s += "Brownian charge: " + charge + "\n";

        s += "\n";
        return s;
    }

    public void out(String message) {

        System.out.println(message);
    }
    
    
    
}
