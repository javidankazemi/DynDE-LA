package MultiSwarm;

import java.util.Random;

import Utilities.MyRandom;

public class MSOUtilities {

	/**
	 * Euclidean distance in dim number of dimensions
	 */
	public static double getEuclideanDistance(double[] a, double[] b, int dim) {

		double distance = 0.0;

		for (int j = 0; j < dim; j++) {

			double diffOfComponents = a[j] - b[j];
			distance += Math.pow(diffOfComponents, 2.0);
		}

		return Math.sqrt(distance);
	}

	/**
	 * Print centres. Method will print number of points that are closer than a
	 * given optimum separation.
	 */
	public static void printCentres(double centres[][], double sep,
			double optimumSep) {

		for (int currCentre = 0; currCentre < centres.length; currCentre++) {

			System.out.println("\n");

			for (int i = 0; i < centres[currCentre].length; i++) {

				int left = (int) centres[currCentre][i] - (int) (sep / 2);
				int right = (int) centres[currCentre][i] + (int) (sep / 2);
				System.out.print("[" + left + ", " + right + "]; ");
			}

		}
		System.out.println();

		int numBelowTolerance = 0;
		System.out
				.println("\nTable of distances between centres. All distances > "
						+ sep);
		for (int i = 0; i < centres.length; i++) {

			for (int j = 0; j < i; j++) {

				double actualSep = getEuclideanDistance(centres[i], centres[j],
						centres[j].length);
				if (actualSep < optimumSep)
					numBelowTolerance++;
				System.out.print((int) actualSep + "  ");
			}
			System.out.println();

		}

		System.out.println("\n\nNumber nearer than " + optimumSep + ": "
				+ numBelowTolerance);
	}

	/**
	 * Method to find points x in [ -range/2, range/2 ]**dim where no two points
	 * ar closer than sep apart
	 */
	public static double[][] findCentres(int numberOfCentres, double sep,
			double range, int dim, Random random) {

		double[][] centres = new double[numberOfCentres][dim];

		for (int currSwarm = 0; currSwarm < numberOfCentres; currSwarm++) {

			boolean failed;
			do {
				failed = false;
				for (int i = 0; i < dim; i++)
					centres[currSwarm][i] = range * (random.nextDouble() - 0.5);

				for (int k = 0; k < currSwarm; k++) {
					if (getEuclideanDistance(centres[k], centres[currSwarm],
							dim) < sep) {
						failed = true;
						break;
					}
				}

				for (int i = 0; i < dim; i++) {
					double left = centres[currSwarm][i] - sep / 2.0;
					double right = left + sep;
					if (left < -range / 2.0 || right > range / 2.0) {
						failed = true;
						break;
					}

				}

			} while (failed);
		}

		return centres;
	}
	
	/**
	 * Method to find points x in [ -range/2, range/2 ]**dim where no two points
	 * ar closer than sep apart
	 */
	public static double[][] findCentres(int numberOfCentres, double sep,
			double range, int dim, MyRandom random) {

		double[][] centres = new double[numberOfCentres][dim];

		for (int currSwarm = 0; currSwarm < numberOfCentres; currSwarm++) {

			boolean failed;
			do {
				failed = false;
				for (int i = 0; i < dim; i++)
					centres[currSwarm][i] = range * (random.nextDouble() - 0.5);

				for (int k = 0; k < currSwarm; k++) {
					if (getEuclideanDistance(centres[k], centres[currSwarm],
							dim) < sep) {
						failed = true;
						break;
					}
				}

				for (int i = 0; i < dim; i++) {
					double left = centres[currSwarm][i] - sep / 2.0;
					double right = left + sep;
					if (left < -range / 2.0 || right > range / 2.0) {
						failed = true;
						break;
					}

				}

			} while (failed);
		}

		return centres;
	}

	public static void main(String[] args) {

		double tolerance = 0.75;

		int numberOfDimensions = 5;
		double dynamicRange = 100.0;

		int numberOfCentres = 10;

		double optimumSep = dynamicRange
				* Math.pow(numberOfCentres, -1.0 / numberOfDimensions);
		double sep = tolerance * optimumSep;

		Random random = new Random(1);

		double[][] centres = findCentres(10, sep, dynamicRange,
				numberOfDimensions, random);
		printCentres(centres, sep, optimumSep);

	}
}
