package MultiSwarm;

import java.util.ArrayList;

import Utilities.MyRandom;

public class Swarm implements Comparable<Swarm> {

    private ArrayList particles;

    private double[] swarmFixedPoint;

    private int index;

    private ArrayList storedValuesList;

    private int maxNumStoredValues = 3;

    private boolean converged;

    private boolean excluded;

    private double dynamicRange;

    private int numberOfDimensions;

    public Swarm() {

        particles = new ArrayList();
        storedValuesList = new ArrayList();
        index = -1;
        converged = false;
        excluded = false;
    }

    public Swarm(int numberOfDimensions, double dynamicRange) {

        this();
        this.numberOfDimensions = numberOfDimensions;
        this.dynamicRange = dynamicRange;
    }

    /*
     * Makes a swarm with numParticlesInSwarm particles, There are
     * numChargedParticlesInSwarm charged particles. x and v are randomised in
     * the search space. p is set to x. g is set to 0.
     */
    public static Swarm makeRandomisedSwarm(int numberOfDimensions,
            double dynamicRange, int numParticlesInSwarm,
            int numChargedParticlesInSwarm, double particleCharge,
            MyRandom random) {

        Swarm swarm = new Swarm(numberOfDimensions, dynamicRange);

        for (int k = 0; k < numParticlesInSwarm; k++) {

            double q = (k < numChargedParticlesInSwarm ? particleCharge : 0.0);
            double[] x = new double[numberOfDimensions];
            
            double[] offspring = new double[numberOfDimensions];
           

            for (int j = 0; j < numberOfDimensions; j++) {

                /*
                 * Randomises (x, v) within [ -xmax/2, xmax/2 ]**d where xmax =
                 * dynamicRange and d = numberOfDimensions.
                 */
                x[j] = dynamicRange * (random.nextDouble() - 0.5);
                offspring[j] = x[j];

            }

            double value = Double.POSITIVE_INFINITY;
            Particle particle = new Particle(x, q, value);
            particle.setOffspring(offspring);
            

            swarm.addParticle(particle);
        }

        swarm.setIndex(0);
        return swarm;
    }

    /**
     * Randomises the whole swarm in the entire search space [ -xmax/2, xmax/2
     * ]**d
     * 
     * Sets p(k) to x(k) Sets fnk to positive infinity and g(n) to zero
     */
    public void randomiseSwarm(MyRandom random) {

        setIndex(0);

        for (int k = 0; k < this.size(); k++) {

            double[] x = new double[numberOfDimensions];
            double[] offspring = new double[numberOfDimensions];

            for (int j = 0; j < numberOfDimensions; j++) {

                /*
                 * Randomises (x, v) within [ -xmax/2, xmax/2 ]**d where xmax =
                 * dynamicRange and d = numberOfDimensions.
                 */
                x[j] = dynamicRange * (random.nextDouble() - 0.5);
                offspring[j] = x[j];
                
            }

            Particle particle = getParticle(k);

            particle.setPosition(x);
            particle.setOffspring(offspring);
            particle.setValue(Double.POSITIVE_INFINITY);
        }
    }

    /**
     * Randomises swarm in a hypercube [-range/2, range/2]**d around a given
     * centre
     * 
     * Sets p(k) to x(k) Sets fnk to positive infinity and g(n) to zero
     */
    public void randomiseSwarm(double[] centres, double range, MyRandom random) {

        setIndex(0);

        for (int k = 0; k < this.size(); k++) {

            double[] x = new double[numberOfDimensions];
            double[] offspring = new double[numberOfDimensions];

            for (int j = 0; j < numberOfDimensions; j++) {

                /*
                 * Randomises (x, v) within [ -range/2, range/2 ]**d where xmax =
                 * dynamicRange and d = numberOfDimensions.
                 */
                x[j] = centres[j] + range * (random.nextDouble() - 0.5);
                offspring[j] = x[j];
            }

            Particle particle = getParticle(k);

            particle.setPosition(x);
            particle.setOffspring(offspring);
            particle.setValue(Double.POSITIVE_INFINITY);
        }
    }

    /**
     * Randomises a fraction f of swarm. The first f*(swarm size) particles are
     * randomised in entire search space.
     * 
     * Sets p(k) to x(k) Sets fnk to positive infinity and g(n) to zero
     */
    public void randomiseSwarm(double frac, MyRandom random) {

        setIndex(0);

        int numToRandomise = Math.round((float) (frac * this.size()));

        for (int k = 0; k < numToRandomise; k++) {

            double[] x = new double[numberOfDimensions];
            double[] offspring = new double[numberOfDimensions];

            for (int j = 0; j < numberOfDimensions; j++) {

                /*
                 * Randomises (x, v) within [ -xmax/2, xmax/2 ]**d where xmax =
                 * dynamicRange and d = numberOfDimensions.
                 */
                x[j] = dynamicRange * (random.nextDouble() - 0.5);
                offspring[j] = x[j];
            }

            Particle particle = this.getParticle(k);

            particle.setPosition(x);
            particle.setOffspring(offspring);
            particle.setValue(Double.POSITIVE_INFINITY);
        }
    }

    public synchronized void addParticle(Particle p) {

        particles.add(p);
    }

    public synchronized void addParticle(int i, Particle p) {

        particles.add(i, p);
    }

    public synchronized Particle getParticle(int i) {

        Particle p = null;

        if (!particles.isEmpty()) {

            try {

                p = (Particle) particles.get(i);
            } catch (IndexOutOfBoundsException e) {

                // Do nothing
            }
        }

        return p;
    }

    public synchronized void removeParticle(int i) {

        Particle p = null;

        if (!particles.isEmpty()) {

            try {
                p = (Particle) particles.remove(i);
            } catch (IndexOutOfBoundsException e) {

                // Do nothing
            }
        }
    }

    public synchronized void setSwarmFixedPoint(double[] x) {

        swarmFixedPoint = x;
    }

    public synchronized double[] getSwarmFixedPoint() {

        return swarmFixedPoint;
    }

    public synchronized double getSwarmFixedPointComponent(int j) {

        return swarmFixedPoint[j];
    }

    public synchronized int getIndex() {

        return index;
    }

    public synchronized void setIndex(int i) {

        if (i < size() && i > -1) {

            index = i;
        } else {

            index = -1;
        }
    }

    public synchronized void setMaxNumStoredValues(int i) {

        maxNumStoredValues = i;
    }

    public int getNumStoredValues() {

        return storedValuesList.size();
    }

    public synchronized void addValue(double d) {

        if (storedValuesList.size() == maxNumStoredValues)
            storedValuesList.remove(0);

        storedValuesList.add(new Double(d));
    }

    public double[] getStoredValues() {

        Double[] bvDoubles = new Double[storedValuesList.size()];
        storedValuesList.toArray(bvDoubles);
        double[] bvArray = new double[bvDoubles.length];

        for (int i = 0; i < bvArray.length; i++)
            bvArray[i] = ((Double) bvDoubles[i]).doubleValue();

        return bvArray;
    }

    public synchronized int size() {

        return particles.size();
    }

    public boolean getConverged() {
        return converged;
    }

    public void setConverged(boolean b) {
        converged = b;
    }

    public boolean getExcluded() {
        return excluded;
    }

    public void setExcluded(boolean b) {
        excluded = b;
    }

    public Particle getWorstParticle() {

        Particle worstP = (Particle) getParticle(0);
        double value = worstP.getValue();
        for (int i = 1; i < size(); ++i) {
            Particle p = (Particle) getParticle(i);
            if (p.getValue() > value)
                worstP = p;

        }
        return worstP;
    }

    public Particle getBestParticle() {

        return getParticle(index);
    }

    public int compareTo(Swarm compareSwarm) {

        double compareQuantity = compareSwarm.getBestParticle().getValue();

            //ascending order
        if (this.getBestParticle().getValue() > compareQuantity)
            return 1;
        else if (this.getBestParticle().getValue() < compareQuantity)
            return -1;
            else
                return 0;

            //descending order
            //return compareQuantity - this.quantity;

    }    

}
