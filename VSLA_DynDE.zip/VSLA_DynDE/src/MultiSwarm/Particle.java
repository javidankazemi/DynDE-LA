package MultiSwarm;

public class Particle {

    private double[] position;

    private double charge;

    private double value;
    
    private double[] offspring;

    public Particle(double[] x, double q, double vl) {

        position = x;
        charge = q;
        value = vl;
    }

    public synchronized double[] getPosition() {

        return position;
    }

    public synchronized double getPositionComponent(int j) {

        return position[j];
    }

    public synchronized void setPosition(double[] x) {

        position = x;
    }

    public synchronized double getCharge() {

        return charge;
    }

    public synchronized void setCharge(double q) {

        charge = q;
    }

    public synchronized double getValue() {

        return value;
    }

    public synchronized void setValue(double vl) {

        value = vl;
    }
    
    public synchronized double[] getOffspring() {

        return offspring;
    }

    public synchronized void setOffspring(double[] child) {

        offspring = child;
    }    
    
}
