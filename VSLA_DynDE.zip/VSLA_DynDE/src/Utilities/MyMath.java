package Utilities;



public class MyMath {


	public static double[] toPolar(double[] cartesian){
		
		if (cartesian.length != 2 )
			return new double[2];
		
		double x = cartesian[0];
		double y = cartesian[1];
		
		double yabs = Math.abs(cartesian[1]);
		double xabs = Math.abs(cartesian[0]);
		double angle = Math.atan(yabs/xabs);
		
		if (x > 0.0 && y < 0.0)
			 angle = 2 * Math.PI - angle;
		else if ( x < 0.0 && y > 0.0)
			angle = Math.PI - angle;
		else if ( x < 0.0 && y < 0.0)
			angle = Math.PI + angle;			
		
		angle = Math.toDegrees(angle);
		
		double radius = Math.pow( (x*x + y*y), 0.5 );
		
		double[] polar = {radius, angle};
		
		return polar;
	}
	
}
