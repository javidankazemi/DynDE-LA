package Utilities;

/**
 * This class sets up a threaded loop.
 * 
 * @version 3.0 June 2002
 * @author Tim Blackwell
 */
public abstract class Loop extends Thread {
    /**
     * This class sets up a threaded loop.
     *  
     */
    public Loop() {
        notFinished = true;
    }

    /**
     * Loop while thread is active. Each iteration calls update(). Loop
     * terminated by setting notFinished to false.
     */
    public void run() {
        notFinished = true;
        while (notFinished) {
            update();
        }
    }

    /**
     * Stops the loop by setting notFinished to false. Thread will terminate.
     */
    public void stopLoop() {
        notFinished = false;
    }

    /**
     * Specifies what the loop does.
     */
    public abstract void update();

    /**
     * Variable to determine end of loop. Volatile since it may be accessible to
     * another unsynchronized thread.
     */
    private volatile boolean notFinished;
}
