package Utilities;

public abstract class Application{

    public Application(){
    }

    public abstract void close();

    public abstract void inform( int i, double d );

}
