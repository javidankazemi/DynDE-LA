/*
 * Created on Sep 26, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package Utilities;

import java.util.ArrayList;

/**
 * @author timblackwell
 * 
 * TODO To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Style - Code Templates
 */
public class Data {

	ArrayList doubleList;
	ArrayList numberList;

	public Data() {

		doubleList = new ArrayList();
		numberList = new ArrayList();
	}

	public void addDouble(double d) {

		doubleList.add(new Double(d));
	}

	public double[] getDoubleData() {

		double[] result = new double[doubleList.size()];

		for (int i = 0; i < doubleList.size(); i++)
			result[i] = ((Double) (doubleList.get(i))).doubleValue();

		return result;
	}
	
	public void addNumber(Number n){
		
		numberList.add(n);
	}
	
	public Number[] getData(){
		
		Number[] result = new Number[numberList.size()];
		for ( int i = 0; i < numberList.size(); i++ ){
			result[i] = (Number)numberList.get(i);
		}
		return result;
	}
}
