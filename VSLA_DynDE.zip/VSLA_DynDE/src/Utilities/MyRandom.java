package Utilities;

import java.util.Random;

public class MyRandom {

	private long seed;

	private Random random;

	public MyRandom(long seed) {

		this.seed = seed;
		random = new Random(seed);

		//  discard a value
		random.nextDouble();
	}

	public MyRandom() {

		this(System.currentTimeMillis());
	}

	/*
	 * Return a pseudorandom number in [0.0, 1.0)
	 */
	public double nextDouble() {

		return random.nextDouble();
	}

	/**
	 * @return
	 */
	public double nextGaussian() {
		// TODO Auto-generated method stub
		return random.nextGaussian();
	}
        
	public int nextInt() {
		// TODO Auto-generated method stub
		return random.nextInt();
	}        

        public int nextInt(int n) {
		// TODO Auto-generated method stub
		return random.nextInt(n);
	}  
	/*
	 * Simple test to show that the first call to
	 * java.util.Random.nextDouble() is correlated to the seed.
	 * 
	 * MyRandom discards the first call to nextDouble.
	 */
	public static void main(String[] args) {

		int numTrials = 1000;
		int numBins = 10;

		long seed = System.currentTimeMillis();
		
		int[] statistics = new int[numBins];
		for (int i = 0; i < numTrials; i++) {
			
			Random r = new Random(seed + i);
			double u = r.nextDouble();
			u *= numBins;
			statistics[(int) u]++;
		}
		System.out.println("Statistics for java.util.Random");
		System.out.println("Bin\t%");
		for (int i = 0; i < statistics.length; i++)
			System.out.println(i + "\t" + (100.0 * statistics[i]) / numTrials);
		System.out.println();

		statistics = new int[numBins];
		for (int i = 0; i < numTrials; i++) {

			MyRandom r = new MyRandom(seed + i);
			double u = r.nextDouble();
			u *= numBins;
			statistics[(int) u]++;
		}
		System.out.println("Statistics for java.util.Random");
		System.out.println("Bin\t%");
		for (int i = 0; i < statistics.length; i++)
			System.out.println(i + "\t" + (100.0 * statistics[i]) / numTrials);
		System.out.println();

	}

}
